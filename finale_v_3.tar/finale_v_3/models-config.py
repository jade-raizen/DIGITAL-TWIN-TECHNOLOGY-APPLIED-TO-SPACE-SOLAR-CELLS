#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
CONFIGURATION CENTRALE — models/config.py (v1.0, BILINGUE)
Central Configuration for the Space Solar Cell Digital Twin
===============================================================================
[FR] Fichier de FONDATION du jumeau numérique. Importé par TOUS les autres
     modules. Ne doit importer AUCUN module du projet (racine du graphe).
[EN] FOUNDATION file of the digital twin. Imported by ALL other modules.
     Must import NO project module (root of the dependency graph).
===============================================================================
"""
from __future__ import annotations
import numpy as np

__version__ = "1.0"

# =============================================================================
# 1. CONSTANTES PHYSIQUES FONDAMENTALES / FUNDAMENTAL PHYSICAL CONSTANTS (SI)
# =============================================================================
K_B    = 1.380649e-23          # Boltzmann [J/K]
K_B_EV = 8.617333262e-5        # Boltzmann [eV/K]
Q      = 1.60217663e-19        # Charge électron [C]
S_REF  = 1367.0                # Irradiance AM0 standard [W/m²]
S1367  = 136.7                 # Irradiance AM0 [mW/cm²]
S1353  = 135.3                 # Irradiance AM0 variante [mW/cm²]
T_REF_K = 301.15               # Température référence 28°C [K]
T_REF_C = 28.0                 # Température référence [°C]
SEED   = 2026                  # Graine aléatoire reproductible
TOL    = 1e-9                  # Tolérance numérique

# =============================================================================
# 2. POIDS DE CONFIANCE / CONFIDENCE WEIGHT SYSTEM
# =============================================================================
POIDS = {
    "datasheet":  1.0,
    "analytique": 0.8,
    "numerique":  0.5,
    "estime":     0.3,
    "inexistant": 0.0,
}

def poids_depuis_source(source: str) -> float:
    """[FR] Retourne le poids de confiance depuis le type de source.
    [EN] Returns confidence weight from source type."""
    return POIDS.get(source, POIDS["inexistant"])

# =============================================================================
# 3. CLASSIFICATION DE RÉVERSIBILITÉ / REVERSIBILITY CLASSIFICATION
# =============================================================================
reversibility_classes = [
    "REVERSIBLE_UNKNOWN",
    "PARTIALLY_REVERSIBLE",
    "CONDITIONALLY_REVERSIBLE",
    "PRACTICALLY_IRREVERSIBLE",
    "FUNDAMENTALLY_IRREVERSIBLE",
    "CATASTROPHIC",
]

# =============================================================================
# 4. CANAUX DE DOMMAGE / DAMAGE CHANNELS
# =============================================================================
STATUT_CANAL = {
    "rad":     "PARTIALLY_REVERSIBLE",
    "thermal": "PRACTICALLY_IRREVERSIBLE",
    "age":     "PRACTICALLY_IRREVERSIBLE",
    "opt":     "PRACTICALLY_IRREVERSIBLE",
    "mech":    "FUNDAMENTALLY_IRREVERSIBLE",
    "ESD":     "FUNDAMENTALLY_IRREVERSIBLE",
    "impact":  "FUNDAMENTALLY_IRREVERSIBLE",
    "TJ":      "PRACTICALLY_IRREVERSIBLE",
}
CANAUX = tuple(STATUT_CANAL.keys())
RECUPERABLES = {k for k, v in STATUT_CANAL.items() if v == "PARTIALLY_REVERSIBLE"}

# =============================================================================
# 5. MÉCANISMES DE RÉGÉNÉRATION / REGENERATION MECHANISMS (9)
# =============================================================================
MECANISMES_REGENERATION = {
    7:  ("Recuit thermique (thermal annealing)",        "rad"),
    8:  ("Recuit in-situ / in-orbit",                    "rad"),
    9:  ("Radiation + recuit simultanés",                "rad"),
    10: ("Recuit multi-défauts (cinétiques différentes)","rad"),
    11: ("Transformation de défauts (D_A→D_B)",          "rad"),
    12: ("Recuit par injection (injection annealing)",   "rad"),
    13: ("Recuit photo-assisté",                         "rad"),
    14: ("Recuit assisté par polarisation (bias)",       "rad"),
    47: ("Auto-guérison naturelle (self-healing)",       "rad"),
}

# =============================================================================
# 6. MATRICE D'EFFET / EFFECT MATRIX
# =============================================================================
PARAMS_ELEC = ("Voc", "Isc", "Vmp", "Imp", "FF", "Rs", "Rsh")
MATRICE_EFFET = {
    "rad":    (0.9,  0.9,  0.9,  0.9,  0.7,  0.05, 0.05),
    "thermal":(0.05, 0.05, 0.5,  0.5,  0.6,  0.6,  0.05),
    "age":    (0.05, 0.05, 0.05, 0.05, 0.05, 0.7,  0.05),
    "opt":    (0.05, 0.95, 0.5,  0.5,  0.1,  0.05, 0.05),
    "mech":   (0.05, 0.6,  0.5,  0.5,  0.6,  0.6,  0.05),
    "ESD":    (0.5,  0.5,  0.5,  0.5,  0.9,  0.05, 0.95),
    "impact": (0.05, 0.7,  0.4,  0.4,  0.5,  0.05, 0.05),
    "TJ":     (0.5,  0.05, 0.5,  0.5,  0.5,  0.7,  0.05),
}

# =============================================================================
# 7. RÈGLES D'HONNÊTETÉ / HONESTY RULES
# =============================================================================
def resultat_non_identifiable(mecanisme: str, raison: str) -> dict:
    """[FR] Retourne un résultat honnête NON_IDENTIFIABLE.
    [EN] Returns an honest NON_IDENTIFIABLE result."""
    return {
        "statut": "NON_IDENTIFIABLE",
        "mecanisme": mecanisme,
        "raison": raison,
        "poids_confiance": POIDS["inexistant"],
    }

# =============================================================================
# 8. FONCTIONS UTILITAIRES / UTILITY FUNCTIONS
# =============================================================================
def C2K(t): return np.asarray(t, dtype=float) + 273.15
def K2C(t): return np.asarray(t, dtype=float) - 273.15

def fraction_restante(dommages: dict, param: str) -> float:
    """[FR] Fraction restante : ∏_i (1 − D_i·w_i). Composition multiplicative.
    [EN] Remaining fraction = product over channels of (1 − D_i·w)."""
    idx = PARAMS_ELEC.index(param)
    frac = 1.0
    for canal, D in dommages.items():
        if D is None:
            continue
        w = MATRICE_EFFET[canal][idx]
        frac *= (1.0 - float(D) * w)
    return float(np.clip(frac, 0.0, 1.0))

def dommage_total(dommages: dict, param: str) -> float:
    """[FR] Dommage total : D_total = 1 − ∏(1 − D_i·w_i).
    [EN] Total damage on X."""
    return 1.0 - fraction_restante(dommages, param)

# =============================================================================
# 9. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  config.py v{__version__} — Configuration centrale chargée")
    print(f"   Canaux de dommage      : {CANAUX}")
    print(f"   Canaux récupérables    : {RECUPERABLES}")
    print(f"   Mécanismes régénération: {len(MECANISMES_REGENERATION)}")
    print(f"   Poids de confiance     : {POIDS}")
    test_dom = {"rad": 0.15, "opt": 0.05}
    for p in PARAMS_ELEC:
        print(f"   D_total({p}) = {dommage_total(test_dom, p):.4f}")