#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE DE RADIATION — models/radiation_model.py (v1.0, BILINGUE)
Radiation Model: Tada law, NIEL, DDD, subcell degradation
===============================================================================
[FR] Modèle de dégradation radiative : loi de Tada, NIEL, DDD.
     Compatible avec jumeau_numerique_final.py v27.
[EN] Radiation degradation model: Tada law, NIEL, DDD.
     Compatible with jumeau_numerique_final.py v27.
===============================================================================
"""
from __future__ import annotations
import numpy as np
from itertools import combinations
from scipy.optimize import brentq

from config import TOL, POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. LOI DE TADA / TADA LAW
# =============================================================================
def eq_int(C, ai, bi, ak, bk):
    """[FR] Équation d'intersection pour extraction C. [EN] Intersection equation."""
    if abs(C) < 1e-12 or abs(ai) < 1e-12 or abs(ak) < 1e-12:
        return np.inf
    ti = np.expm1(np.clip(ai / C, -100, 100))
    tk = np.expm1(np.clip(ak / C, -100, 100))
    if abs(ti) < 1e-15 or abs(tk) < 1e-15:
        return np.inf
    return bi / ti - bk / tk

def evaluer(C, P0, v, f):
    """[FR] Évalue R² du fit. [EN] Evaluates R² of the fit."""
    if abs(P0) < 1e-12:
        return None
    a = 1 + np.asarray(f) / P0
    if np.any(a <= 0):
        return None
    p = v[0] * (1 - C * np.log(a))
    if not np.all(np.isfinite(p)):
        return None
    ss = np.sum((v - p) ** 2)
    st = np.sum((v - v.mean()) ** 2)
    return 1 - ss / st if st > 0 else 1.0

def C_conservateur(P0, v, f):
    """[FR] Projection conservative C*. [EN] Conservative projection C*."""
    a = 1 - np.asarray(v) / v[0]
    lt = np.log(1 + np.asarray(f, float) / P0)
    m = lt > 1e-12
    return float(np.max(np.where(m, a / np.where(m, lt, 1.), 0.)))

def selection_conservatrice(v, f):
    """[FR] Extraction (C*, Φ₀, R²) analytique + projection.
    [EN] Analytic extraction of (C*, Φ₀, R²)."""
    x0 = v[0]
    a = 1 - np.asarray(v) / x0
    b = np.asarray(f, float)
    idx = [i for i in range(len(a)) if abs(a[i]) > 1e-9]
    sols = []
    
    for lo0, hi0 in [(1e-5, 0.30), (-0.30, -1e-5)]:
        for i, k in combinations(idx, 2):
            g = np.linspace(lo0, hi0, 200)
            for lo, hi in zip(g[:-1], g[1:]):
                fa, fb = eq_int(lo, a[i], b[i], a[k], b[k]), eq_int(hi, a[i], b[i], a[k], b[k])
                if np.isfinite(fa) and np.isfinite(fb) and fa * fb <= 0:
                    try:
                        cs = brentq(lambda C: eq_int(C, a[i], b[i], a[k], b[k]), lo, hi)
                    except Exception:
                        continue
                    den = np.expm1(np.clip(a[i] / cs, -100, 100))
                    if abs(den) < 1e-15:
                        continue
                    P0 = b[i] / den
                    r2 = evaluer(cs, P0, v, f)
                    if r2 is not None:
                        sols.append((cs, P0, r2))
    
    phys = [s for s in sols if s[0] > 0 and s[1] > 0]
    if not phys:
        neg = [s for s in sols if s[0] < 0 and s[1] < 0]
        if not neg:
            return None
        bn = max(neg, key=lambda s: s[2])
        phys = [(abs(bn[0]), abs(bn[1]), bn[2])]
    
    proj = []
    for cs, P0, r2 in phys:
        cc = C_conservateur(P0, v, f)
        r = evaluer(cc, P0, v, f)
        if r is None or cc <= 0:
            continue
        p = v[0] * (1 - cc * np.log(1 + np.asarray(f) / P0))
        if np.max((p - v) / v) <= TOL:
            proj.append((cc, P0, r))
    
    return max(proj, key=lambda s: s[2]) if proj else None

# =============================================================================
# 2. PRÉDICTION DÉGRADATION / DEGRADATION PREDICTION
# =============================================================================
def predire_degradation(v_bol, C, Phi0, fluence):
    """[FR] Prédit la valeur dégradée selon Tada. [EN] Predicts degraded value."""
    if C is None or Phi0 is None:
        return None
    ratio = 1 + fluence / Phi0
    if ratio <= 0:
        return None
    return v_bol * (1 - C * np.log(ratio))

# =============================================================================
# 3. RDC / RELATIVE DAMAGE COEFFICIENTS
# =============================================================================
def convertir_fluence_rdc(fluence, rdc):
    """[FR] Convertit une fluence via RDC. [EN] Converts fluence via RDC."""
    if rdc is None or rdc <= 0:
        return resultat_non_identifiable("RDC", "RDC manquant ou invalide")
    return fluence * rdc

# =============================================================================
# 4. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  radiation_model.py v{__version__}")
    # Test avec données 3G30C
    voc = np.array([2.700, 2.620, 2.570, 2.510])
    flu = np.array([0.0, 2.5, 5.0, 10.0])
    result = selection_conservatrice(voc, flu)
    if result:
        C, Phi0, R2 = result
        print(f"   C* = {C:.6e}")
        print(f"   Φ₀ = {Phi0:.6e}")
        print(f"   R² = {R2:.4f}")
    else:
        print("   ❌ Extraction échouée")