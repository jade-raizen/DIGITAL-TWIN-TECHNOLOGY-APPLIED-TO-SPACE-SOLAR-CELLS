#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE ÉLECTRIQUE — models/electrical_model.py (v1.0, BILINGUE)
Electrical Model: 1-diode + Lambert W extraction
===============================================================================
[FR] Modèle électrique 1-diode avec extraction des paramètres par Lambert W.
     Compatible avec jumeau_numerique_final.py v27.
[EN] 1-diode electrical model with Lambert W parameter extraction.
     Compatible with jumeau_numerique_final.py v27.
===============================================================================
"""
from __future__ import annotations
import numpy as np
from scipy.special import lambertw
from scipy.optimize import brentq

from config import K_B, Q, S_REF, T_REF_K, TOL

__version__ = "1.0"

# =============================================================================
# 1. EXTRACTION DIODE LAMBERT W / LAMBERT W DIODE EXTRACTION
# =============================================================================
def extraire_diode(voc, isc, vmp, imp, t_k, ns=3):
    """[FR] 1-diode (Lambert W), entrées SI. [EN] 1-diode (Lambert W), SI inputs.
    
    Parameters:
        voc: Open-circuit voltage [V]
        isc: Short-circuit current [A]
        vmp: Voltage at MPP [V]
        imp: Current at MPP [A]
        t_k: Temperature [K]
        ns: Number of series junctions
    
    Returns:
        dict with I_pv, I_0, R_s, N_a, P_max or None
    """
    v1 = (K_B * t_k) / Q
    best = (1e9, None)
    
    for nat in np.linspace(ns * 0.8, ns * 2.5, 60):
        vt = nat * v1
        if vt < 1e-4:
            continue
        
        i0 = isc / (np.exp(np.clip(voc / vt, -80, 80)) - 1)
        if i0 <= 1e-20 or not np.isfinite(i0):
            continue
        
        ipv = isc + i0 * (np.exp(np.clip(isc * 0.01 / vt, -80, 80)) - 1)
        al = 1 + (ipv - imp) / i0
        if al <= 1:
            continue
        
        rs = (vt * np.log(al) - vmp) / imp
        if rs < 1e-5 or rs > 2:
            continue
        
        vv = np.linspace(0, voc, 300)
        aw = (i0 * rs / vt) * np.exp(np.clip((vv + (ipv + i0) * rs) / vt, -80, 80))
        w = np.real(lambertw(np.nan_to_num(aw, nan=0., posinf=1e8, neginf=-1/np.e)))
        iv = np.maximum(ipv + i0 - (vt / rs) * w, 0.)
        pv = vv * iv
        im = int(np.argmax(pv))
        e = abs(pv[im] - vmp * imp) / (vmp * imp)
        
        if e < best[0]:
            best = (e, dict(I_pv=ipv, I_0=i0, R_s=rs, N_a=nat/ns, P_max=pv[im]))
    
    return best[1]

# =============================================================================
# 2. COURBE I-V / I-V CURVE
# =============================================================================
def courbe_iv(d, voc, t_k, ns):
    """[FR] Génère la courbe I-V complète. [EN] Generates full I-V curve."""
    v1 = (K_B * t_k) / Q
    vt = d["N_a"] * ns * v1
    vv = np.linspace(0, voc, 400)
    aw = (d["I_0"] * d["R_s"] / vt) * np.exp(
        np.clip((vv + (d["I_pv"] + d["I_0"]) * d["R_s"]) / vt, -80, 80))
    w = np.real(lambertw(np.nan_to_num(aw, nan=0., posinf=1e8, neginf=-1/np.e)))
    iv = np.maximum(d["I_pv"] + d["I_0"] - (vt / d["R_s"]) * w, 0.)
    return vv, iv, vv * iv

# =============================================================================
# 3. CALIBRATION R_s FIXÉ / FIXED-Rs CALIBRATION
# =============================================================================
def caler_diode_rs_fixe(voc, isc, vm, im, rs, t_k, ns=3, n_lo=None, n_hi=None):
    """[FR] R_s fixé + (Vmpp,Impp) imposé → (I_pv, I₀, N_a).
    [EN] Fixed Rs + MPP imposed → (I_pv, I₀, N_a)."""
    n_lo = n_lo or 0.5 * ns
    n_hi = n_hi or 3.0 * ns
    
    def _i0_ipv_pour_n(n):
        vt = n * (K_B * t_k) / Q
        E_voc = np.exp(np.clip(voc / vt, -80, 80))
        E_isc = np.exp(np.clip(isc * rs / vt, -80, 80))
        den = E_voc - E_isc
        if den <= 0:
            return None, None, vt
        I0 = isc / den
        Ipv = I0 * (E_voc - 1)
        return I0, Ipv, vt
    
    def residu(n):
        I0, Ipv, vt = _i0_ipv_pour_n(n)
        if I0 is None:
            return np.inf
        E_m = np.exp(np.clip((vm + im * rs) / vt, -80, 80))
        return Ipv - I0 * (E_m - 1) - im
    
    g = np.linspace(n_lo, n_hi, 200)
    fg = np.array([residu(x) for x in g])
    idx = np.where(np.diff(np.sign(fg)) != 0)[0]
    if len(idx) == 0:
        return None
    
    n_sol = brentq(residu, g[idx[0]], g[idx[0] + 1])
    I0, Ipv, vt = _i0_ipv_pour_n(n_sol)
    return dict(I_pv=Ipv, I_0=I0, R_s=rs, N_a=n_sol / ns)

# =============================================================================
# 4. CORRECTIONS ECSS / ECSS CORRECTIONS
# =============================================================================
def corriger_irradiance(voc, isc, vmp, imp, ns, t_k, S):
    """[FR] Correction ECSS : Isc∝S ; Voc+=N_s·V_t·ln(S/S_ref).
    [EN] ECSS irradiance correction."""
    sr = max(S / S_REF, 1e-6)
    vt = (ns * K_B * t_k) / Q
    isc_o = max(isc * sr, 1e-9)
    voc_o = max(voc + vt * np.log(sr), 1e-4)
    pmp_o = max(vmp * imp * sr, 1e-9)
    vmp_o = min(max(vmp + vt * np.log(sr), 1e-4), voc_o * 0.98)
    return voc_o, isc_o, vmp_o, min(max(pmp_o / vmp_o, 1e-9), isc_o * 0.98)

# =============================================================================
# 5. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  electrical_model.py v{__version__}")
    # Test avec données 3G30C BOL
    voc, isc, vmp, imp = 2.700, 0.5202, 2.411, 0.5044
    d = extraire_diode(voc, isc, vmp, imp, T_REF_K, ns=3)
    if d:
        print(f"   I_pv = {d['I_pv']*1e3:.2f} mA")
        print(f"   I_0  = {d['I_0']:.3e} A")
        print(f"   R_s  = {d['R_s']*1e3:.3f} mΩ")
        print(f"   N_a  = {d['N_a']:.3f}")
        print(f"   P_max = {d['P_max']:.4f} W")
        err = abs(d['P_max'] - vmp*imp) / (vmp*imp)
        print(f"   Erreur MPP : {err:.2%} {'PASS' if err < 0.02 else 'FAIL'}")
    else:
        print("   ❌ Extraction échouée")