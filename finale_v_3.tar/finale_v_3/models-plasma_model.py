#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE PLASMA — models/plasma_model.py (v1.0, BILINGUE)
Plasma Model: Surface charging, differential charging, current collection
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. COLLECTE DE COURANT OML / OML CURRENT COLLECTION
# =============================================================================
def courant_oml(I_0, V, T_i_eV):
    """[FR] Courant ionique OML : I_i = I_0·(1 - eV/kTi)^(1/2).
    [EN] OML ion current."""
    if T_i_eV <= 0:
        return 0.0
    arg = 1 - V / T_i_eV
    if arg < 0:
        return 0.0
    return I_0 * np.sqrt(arg)

# =============================================================================
# 2. CHARGING DE SURFACE / SURFACE CHARGING
# =============================================================================
def equilibre_charging(I_e, I_i, I_ph, I_SEE):
    """[FR] Équilibre de charging : I_e + I_i + I_ph + I_SEE = 0.
    [EN] Charging equilibrium."""
    I_total = I_e + I_i + I_ph + I_SEE
    return {
        "statut": "actif",
        "I_total": float(I_total),
        "charging_equilibre": abs(I_total) < 1e-12,
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  plasma_model.py v{__version__}")
    res = equilibre_charging(-1e-9, 5e-10, 3e-10, 2e-10)
    print(f"   I_total = {res['I_total']:.2e} A, équilibré: {res['charging_equilibre']}")