#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE ESD — models/esd_model.py (v1.0, BILINGUE)
ESD Model: Surface discharge, flashover, vacuum discharge, ESD damage
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. DOMMAGE ESD / ESD DAMAGE
# =============================================================================
def dommage_esd(I_discharge, R_path, t_duration):
    """[FR] Énergie de décharge Q = I²·R·t. PERMANENT.
    [EN] Discharge energy. PERMANENT."""
    if I_discharge is None or R_path is None or t_duration is None:
        return resultat_non_identifiable("esd_damage", "Paramètres manquants")
    Q = I_discharge ** 2 * R_path * t_duration
    return {
        "statut": "actif",
        "canal": "ESD",
        "energie_J": float(Q),
        "reversible": False,
        "poids_confiance": POIDS["estime"],
    }

# =============================================================================
# 2. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  esd_model.py v{__version__}")
    res = dommage_esd(1.0, 10.0, 1e-3)
    if res["statut"] == "actif":
        print(f"   Énergie ESD = {res['energie_J']:.4f} J")