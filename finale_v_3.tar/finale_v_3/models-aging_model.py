#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE DE VIEILLISSEMENT — models/aging_model.py (v1.0, BILINGUE)
Aging Model: Intrinsic aging, interdiffusion, contact degradation
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import K_B_EV, POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. VIEILLISSEMENT INTRINSÈQUE / INTRINSIC AGING
# =============================================================================
def vieillissement_intrinseque(t_annees, taux_par_an=None):
    """[FR] Dérive intrinsèque D_age = taux × t. PERMANENT.
    [EN] Intrinsic drift. PERMANENT."""
    if taux_par_an is None:
        return resultat_non_identifiable("intrinsic_aging", "Taux de dérive manquant")
    return {
        "statut": "actif",
        "canal": "age",
        "D_age": float(np.clip(taux_par_an * t_annees, 0.0, 1.0)),
        "reversible": False,
        "poids_confiance": POIDS["numerique"],
    }

# =============================================================================
# 2. INTERDIFFUSION / INTERDIFFUSION
# =============================================================================
def interdiffusion(T_K, time_s, D0=None, Ea_D=None):
    """[FR] Profondeur d'interdiffusion x = √(2·D·t). PERMANENT.
    [EN] Interdiffusion depth. PERMANENT."""
    if D0 is None or Ea_D is None:
        return resultat_non_identifiable("interdiffusion", "D0 et Ea manquants")
    D = D0 * np.exp(-Ea_D / (K_B_EV * max(T_K, 1.0)))
    x = np.sqrt(2 * D * time_s)
    return {
        "statut": "actif",
        "canal": "age",
        "x_diff_cm": float(x),
        "reversible": False,
        "poids_confiance": POIDS["numerique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  aging_model.py v{__version__}")
    res = vieillissement_intrinseque(10.0, taux_par_an=0.001)
    if res["statut"] == "actif":
        print(f"   D_age(10 ans) = {res['D_age']:.4f}")