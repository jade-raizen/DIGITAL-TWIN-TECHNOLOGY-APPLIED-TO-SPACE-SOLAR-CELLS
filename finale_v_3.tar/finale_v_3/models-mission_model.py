#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE MISSION — models/mission_model.py (v1.0, BILINGUE)
Mission Model: Orbital environment integration, mission profile
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. PROFIL MISSION / MISSION PROFILE
# =============================================================================
def charger_profil_mission(profil):
    """[FR] Charge et valide un profil de mission.
    [EN] Loads and validates a mission profile."""
    if not profil:
        return resultat_non_identifiable("mission", "Profil manquant")
    
    required = ["nom", "orbite", "duree_annees"]
    for k in required:
        if k not in profil:
            return resultat_non_identifiable("mission", f"Champ '{k}' manquant")
    
    return {
        "statut": "actif",
        "profil": profil,
        "poids_confiance": POIDS["datasheet"],
    }

# =============================================================================
# 2. INTÉGRATION DÉGRADATION MISSION / MISSION DEGRADATION INTEGRATION
# =============================================================================
def integrer_degradation_mission(profil, fluence_totale, taux_recuit=None):
    """[FR] Intègre la dégradation sur la durée de la mission.
    [EN] Integrates degradation over mission duration."""
    if profil is None or fluence_totale is None:
        return resultat_non_identifiable("mission_integration", "Données manquantes")
    
    # Simplifié : dégradation nette = dégradation - recuit
    degradation_nette = fluence_totale
    if taux_recuit is not None and taux_recuit > 0:
        degradation_nette = max(fluence_totale - taux_recuit * profil.get("duree_annees", 0), 0)
    
    return {
        "statut": "actif",
        "fluence_totale": float(fluence_totale),
        "degradation_nette": float(degradation_nette),
        "poids_confiance": POIDS["numerique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  mission_model.py v{__version__}")
    profil = {"nom": "LEO_ISS", "orbite": "LEO", "duree_annees": 15.0}
    res = charger_profil_mission(profil)
    if res["statut"] == "actif":
        print(f"   Profil chargé : {res['profil']['nom']}")