#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE TRIPLE JONCTION — models/tj_model.py (v1.0, BILINGUE)
TJ Model: Current matching, subcell degradation, tunnel junction
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. CURRENT MATCHING 3J / 3J CURRENT MATCHING
# =============================================================================
def current_matching_3j(Isc_top, Isc_mid, Isc_bot):
    """[FR] Isc_3J = min(Isc_top, Isc_mid, Isc_bot).
    [EN] 3J current matching."""
    if any(x is None for x in (Isc_top, Isc_mid, Isc_bot)):
        return resultat_non_identifiable("current_matching", "Courants sous-cellules manquants")
    
    Isc_3J = min(Isc_top, Isc_mid, Isc_bot)
    if Isc_3J == Isc_top:
        limitante = "top"
    elif Isc_3J == Isc_mid:
        limitante = "middle"
    else:
        limitante = "bottom"
    
    return {
        "statut": "actif",
        "Isc_3J": float(Isc_3J),
        "sous_cellule_limitante": limitante,
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 2. VOC TOTAL TJ / TOTAL TJ VOC
# =============================================================================
def voc_total_3j(Voc_top, Voc_mid, Voc_bot, V_TJ_losses=0.0):
    """[FR] Voc_TJ = Σ Voc_i - pertes TJ.
    [EN] Total TJ voltage."""
    if any(x is None for x in (Voc_top, Voc_mid, Voc_bot)):
        return resultat_non_identifiable("voc_3j", "Tensions sous-cellules manquantes")
    Voc_total = Voc_top + Voc_mid + Voc_bot - V_TJ_losses
    return {
        "statut": "actif",
        "Voc_3J": float(Voc_total),
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  tj_model.py v{__version__}")
    res = current_matching_3j(0.180, 0.175, 0.190)
    if res["statut"] == "actif":
        print(f"   Isc_3J = {res['Isc_3J']*1e3:.1f} mA, limitante: {res['sous_cellule_limitante']}")