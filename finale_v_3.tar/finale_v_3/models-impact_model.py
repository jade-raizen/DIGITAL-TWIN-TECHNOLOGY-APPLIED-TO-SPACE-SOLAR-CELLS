#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE IMPACT — models/impact_model.py (v1.0, BILINGUE)
Impact Model: Paul-Berthoud cratering, MMOD, debris
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. CRATÈRE PAUL-BERTHOUD / PAUL-BERTHOUD CRATER
# =============================================================================
def diametre_cratere(d_cm, rho_g_cm3, v_km_s, rho_t_g_cm3, theta_deg=0.0):
    """[FR] Équation Paul-Berthoud : Dco = 5E-4·d^1.076·ρ^0.784·v^0.727·cos(θ)^0.601·ρt^-0.5
    [EN] Paul-Berthoud crater diameter."""
    v_cm_s = v_km_s * 1e5
    cos_t = np.cos(np.radians(theta_deg))
    Dco = 5e-4 * d_cm**1.076 * rho_g_cm3**0.784 * v_cm_s**0.727 \
          * cos_t**0.601 * rho_t_g_cm3**(-0.5)
    return {
        "statut": "actif",
        "canal": "impact",
        "Dco_cm": float(Dco),
        "reversible": False,
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 2. CHARGE PLASMA D'IMPACT / IMPACT PLASMA CHARGE
# =============================================================================
def charge_plasma_impact(m_g, v_km_s):
    """[FR] Q = 0.1·m·(m/1E-11)^0.02·(v/5)^3.48 (Rival & Mandeville 1999)
    [EN] Impact plasma charge."""
    Q = 0.1 * m_g * (m_g / 1e-11)**0.02 * (v_km_s / 5.0)**3.48
    return {
        "statut": "actif",
        "Q_C": float(Q),
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  impact_model.py v{__version__}")
    res = diametre_cratere(0.001, 2.5, 10.0, 2.5)
    if res["statut"] == "actif":
        print(f"   Dco = {res['Dco_cm']*1e4:.1f} µm")