#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE THERMIQUE — models/thermal_model.py (v1.0, BILINGUE)
Thermal Model: Instantaneous T effect + Cumulative thermal aging
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import K_B, Q, C2K, K2C, T_REF_K, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. EFFET THERMIQUE INSTANTANÉ / INSTANTANEOUS THERMAL EFFECT
# =============================================================================
def corriger_temperature(voc, isc, vmp, imp, dT, coeffs):
    """[FR] Correction thermique linéaire. [EN] Linear thermal correction."""
    out = {}
    if abs(dT) < 1e-12:
        return {"Voc": voc, "Isc": isc, "Vmp": vmp, "Imp": imp}
    
    out["Voc"] = max(voc + coeffs.get("dVoc", 0) * dT, 1e-9)
    out["Isc"] = max(isc + coeffs.get("dIsc", 0) * dT, 1e-9)
    out["Vmp"] = max(vmp + coeffs.get("dVmp", 0) * dT, 1e-9)
    out["Imp"] = max(imp + coeffs.get("dImp", 0) * dT, 1e-9)
    return out

# =============================================================================
# 2. VIEILLISSEMENT THERMIQUE CUMULATIF / CUMULATIVE THERMAL AGING
# =============================================================================
def vieillissement_thermal(T_hist_K, t_h, A=None, Ea_eV=None):
    """[FR] Dose Arrhenius cumulée H = ∫k[T(t)]dt. PERMANENT.
    [EN] Cumulative Arrhenius dose. PERMANENT."""
    if A is None or Ea_eV is None:
        return resultat_non_identifiable("thermal_aging", "A et Ea manquants")
    
    T = np.asarray(T_hist_K, float)
    k = A * np.exp(-Ea_eV / (K_B * 1e-3 * np.maximum(T, 1.0)))  # Ea en eV
    dose = float(np.trapz(k, dx=(t_h / max(len(T) - 1, 1))))
    return {
        "statut": "actif",
        "canal": "thermal",
        "D_thermal": float(np.clip(dose, 0.0, 1.0)),
        "reversible": False,
        "poids_confiance": 0.5,
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  thermal_model.py v{__version__}")
    # Test effet instantané
    coeffs = {"dVoc": -6.2e-3, "dIsc": 0.36e-3, "dVmp": -6.7e-3, "dImp": 0.24e-3}
    result = corriger_temperature(2.700, 0.5202, 2.411, 0.5044, 10.0, coeffs)
    print(f"   Voc(38°C) = {result['Voc']:.4f} V (attendu ~2.638)")
    print(f"   Isc(38°C) = {result['Isc']*1e3:.2f} mA (attendu ~523.8)")