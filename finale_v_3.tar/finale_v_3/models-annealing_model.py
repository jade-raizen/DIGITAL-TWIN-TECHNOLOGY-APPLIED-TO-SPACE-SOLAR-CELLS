#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE DE RECUIT — models/annealing_model.py (v1.0, BILINGUE)
Annealing Model: 9 recovery mechanisms (REC_007 to REC_047)
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import K_B_EV, POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. TAUX DE RECUIT ARRHENIUS / ARRHENIUS ANNEALING RATE
# =============================================================================
def taux_recuit_arrhenius(A, Ea_eV, T_K, assistance=None):
    """[FR] Constante de taux k(T) = A·exp(−Ea/k_BT) × facteur d'assistance.
    [EN] Arrhenius rate constant with optional assistance factor."""
    if A is None or Ea_eV is None or T_K is None:
        return None
    k = A * np.exp(-Ea_eV / (K_B_EV * max(float(T_K), 1.0)))
    if assistance and assistance.get("beta"):
        k = k * (1.0 + assistance["beta"] * assistance.get("x", 0.0))
    return float(k)

# =============================================================================
# 2. INTÉGRATION RECUIT / ANNEALING INTEGRATION
# =============================================================================
def integrer_recuit(familles, t_h, T_K_of_t, G_of_t=None, assistance_of_t=None, dt_h=0.1):
    """[FR] Intègre dD_i/dt = G_i(t) − k_i(T,X)·D_i pour chaque famille.
    [EN] Integrates defect kinetics per family."""
    D = {f["nom"]: float(f.get("D0", 1.0)) for f in familles}
    hist = {n: [v] for n, v in D.items()}
    n_steps = int(t_h / dt_h)
    
    for step in range(n_steps):
        t = step * dt_h
        T_K = T_K_of_t(t)
        ass = assistance_of_t(t) if assistance_of_t else None
        for f in familles:
            k = taux_recuit_arrhenius(f["A"], f["Ea"], T_K, ass)
            if k is None:
                continue
            G = G_of_t(t).get(f["nom"], 0.0) if G_of_t else 0.0
            D[f["nom"]] = max(D[f["nom"]] + (G - k * D[f["nom"]]) * dt_h, 0.0)
            hist[f["nom"]].append(D[f["nom"]])
    
    return D, hist

# =============================================================================
# 3. POINT D'ENTRÉE RECUIT / ANNEALING ENTRY POINT
# =============================================================================
def run_recuit(cfg):
    """[FR] Point d'entrée unifié du recuit. Valide, calcule, retourne.
    S'applique UNIQUEMENT au canal D_rad.
    [EN] Unified annealing entry point. Applies ONLY to D_rad channel."""
    if not cfg or not cfg.get("actif", False):
        return resultat_non_identifiable("recuit", "Recuit inactif ou config absente")
    
    familles = cfg.get("familles", [])
    if not familles:
        return resultat_non_identifiable("recuit", "Familles de défauts manquantes")
    
    for f in familles:
        if not all(k in f for k in ("nom", "A", "Ea")):
            return resultat_non_identifiable("recuit", f"Famille '{f.get('nom','?')}' incomplète")
    
    T_profil = cfg.get("T_profil") or cfg.get("profil_T_orbital")
    if T_profil is None:
        return resultat_non_identifiable("recuit", "Profil T(t) manquant")
    
    tp = np.asarray(T_profil, float)
    if tp.ndim != 2 or tp.shape[1] != 2:
        return resultat_non_identifiable("recuit", "T_profil doit être [[t_h,T_K],...]")
    
    T_of_t = lambda t: float(np.interp(t, tp[:, 0], tp[:, 1]))
    t_fin = float(cfg.get("t_h", tp[-1, 0]))
    
    ass_of_t = None
    if cfg.get("assistance"):
        a = cfg["assistance"]
        ass_of_t = lambda t: {"type": a.get("type"), "x": a.get("x", 0.0), "beta": a.get("beta", 0.0)}
    
    G_of_t = None
    if cfg.get("G_rad"):
        G_rad = cfg["G_rad"]
        G_of_t = lambda t: {f["nom"]: G_rad for f in familles}
    
    D_final, hist = integrer_recuit(familles, t_fin, T_of_t, G_of_t=G_of_t, assistance_of_t=ass_of_t)
    
    ratios = [D_final[f["nom"]] / max(f.get("D0", 1.0), 1e-30) for f in familles if f.get("D0", 1.0) > 0]
    recup = 1.0 - float(np.mean(ratios)) if ratios else 0.0
    
    return {
        "statut": "actif",
        "mecanisme": cfg.get("type_recuit", "arrhenius"),
        "canal_cible": "rad",
        "recuperation_pct": 100.0 * recup,
        "D_rad_final": float(np.mean(list(D_final.values()))),
        "D_par_famille": {k: float(v) for k, v in D_final.items()},
        "poids_confiance": POIDS["numerique"],
    }

# =============================================================================
# 4. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  annealing_model.py v{__version__}")
    cfg = {
        "actif": True, "type_recuit": "arrhenius", "t_h": 100.0,
        "T_profil": [[0, 300.0], [50, 350.0], [100, 300.0]],
        "familles": [{"nom": "E1", "A": 1e9, "Ea": 0.85, "D0": 1.0}],
    }
    res = run_recuit(cfg)
    if res["statut"] == "actif":
        print(f"   Récupération = {res['recuperation_pct']:.1f}%")
    else:
        print(f"   ❌ {res['raison']}")