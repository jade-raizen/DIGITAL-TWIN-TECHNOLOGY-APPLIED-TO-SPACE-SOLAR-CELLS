#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
JUMEAU NUMÉRIQUE DE CELLULES SOLAIRES SPATIALES — v28 (FINAL, BILINGUE)
Digital Twin of Space Solar Cells: Conservative Degradation, Diode Extraction,
8-Channel Damage, Annealing, Subcells, Mission Profiles (Cryo/LLL)
===============================================================================
[FR] Prédit, à partir des données réelles (datasheets), l'évolution sous
     rayonnement (Φ), température (T) et irradiance (S) :
     • Dégradation radiative conservative : extraction analytique (C*, Φ₀) [31]
     • Diode équivalente : 1-diode + 2-diodes LLL, Lambert W explicite [32,33]
     • Corrections thermo-optiques (normalisation ECSS) [34]
     • Incertitude : bootstrap non paramétrique (IC 95 %) [7]
     • Sécurité orbitale : prédiction jamais supérieure à la mesure
     • Calibration à R_s fixé (module [15]) ; variables fixées (module [16])
     • [v28-F3] Fluence structurée {particule, énergie, unité, fluence_type,
                RDC mesuré} depuis solar_cells_db.py v28
     • [v28-F5] Diode enrichie : seuil de rejet 5 %, R_sh optionnel,
                poids de confiance, statut (actif/REJETÉ/NON_IDENTIFIABLE)
     • [v28-M17] Dommage total 8 canaux (composition multiplicative)
     • [v28-M18] Recuit & récupération (9 mécanismes REC_007–REC_047)
     • [v28-M19] Vieillissement thermique Arrhenius (PERMANENT)
     • [v28-M20] Impacts & ESD (Paul-Berthoud, énergie Joule)
     • [v28-M21] RDC / fluence équivalente 1 MeV (Rapport RT3 CDS)
     • [v28-M23] Sous-cellules 3J + current matching (Kirchhoff série)
     • [v28-M24] Dégradation optique (Beer-Lambert)
     • [v28-M25] Profil mission (LEO/GEO/JUICE/MARS) + flag LLL/cryo

[EN] Predicts space solar-cell evolution under radiation (Phi), temperature (T)
     and irradiance (S): conservative degradation, single-diode Lambert-W model,
     ECSS corrections, bootstrap UQ, never-above safety, fixed-Rs calibration,
     external-value anchoring, structured fluence (F3), enriched diode (F5),
     8-channel damage composition, annealing (9 mechanisms), thermal aging,
     impacts/ESD, RDC, 3J subcells, optics, and mission profiles.

CORRECTIFS v26 / v26 FIXES :
   • [1] THERMO homogénéisé en SI (V/K, A/K) cohérent avec normaliser_si
   • [2] run_bench : WARNING si flag OU eff > 40 % (tuiles/assemblages)
   • [3] run_export : feuille dynamique Benchmark{N} (au lieu de "Benchmark92")

AJOUTS v27 / v27 ADDITIONS :
   • [S1] POIDS de confiance + rapport_provenance()
   • [S2] Traçage du repli THERMO générique dans ETAT + journal
   • [F2] provenance_elec visible dans le rapport
   • [F4] component_type visible dans le rapport

NOUVEAUTÉS v28 / v28 ADDITIONS :
   • [F3] Fluence structurée {particule, énergie, unité, type, RDC}
   • [F5] SEUIL_REJET = 5 % + R_sh optionnel + poids confiance + statut
   • [F5] Modèle 2-diodes LLL pour irradiance < 200 W/m² (mode cryogénique)
   • [M17-M25] 9 nouveaux modules physiques avancés
   • Import conditionnel des moteurs models/*.py (repli gracieux)

SOURCE : solar_cells_database.yaml (via solar_cells_db v28)
         OU donnees_cellules_88.py (repli legacy)
NORMES : ECSS-E-ST-20-08C Rev.2 (2023) ; MIL-STD-810H ; NASA-STD-8739

USAGE :
   python jumeau_numerique_final.py                          # menu interactif
   python jumeau_numerique_final.py --mode full              # pipeline complet
   python jumeau_numerique_final.py --mode modules --modules "1 2 3 4"
   python jumeau_numerique_final.py --mission JUICE_JUPITER  # mode cryogénique

RÉFÉRENCES / REFERENCES
   [7]   Efron & Tibshirani, An Introduction to the Bootstrap, 1993.
   [28]  Pindado & Cubas, Renewable Energy 103, 2017.
   [29]  Pindado et al., Energies 11, 2018.
   [31]  Tada et al., Solar Cell Radiation Handbook, JPL 82-69, 1982.
   [32]  Jain & Kapoor, Solar Energy Materials, 2004.
   [33]  Corless et al., On the Lambert W function, Adv. Comput. Math. 5, 1996.
   [34]  ECSS-E-ST-20-08C Rev.2, ESA-ESTEC, 20 avril 2023.
   [35]  Messenger et al., Prog. Photovolt. 9(2), 103-121, 2001.
   [36]  Baur & Bett, IEEE PVSC, 2010.
   [37]  Imaizumi et al., Prog. Photovolt. 25(2), 161-174, 2017.
   [105] Rival & Mandeville, Space Debris 1(1), 37-48, 1999.
   [107] Paul & Berthoud, AIAA, 1995.
   [A]   Blanco et al., ESPC 2016.
   [B]   Paige et al., Space Sci. Rev. 150, 2010.
   RT3   Rapport RT3 CDS 25.DING.ING.PCCEC (RDC protonique 2.66, 9.03).
===============================================================================
"""
from __future__ import annotations

import argparse, hashlib, json, sys, time, warnings
from concurrent.futures import ProcessPoolExecutor
from contextlib import contextmanager
from itertools import combinations
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np, pandas as pd, matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.special import lambertw

# =============================================================================
# CHARGEMENT DES DONNÉES + PROVENANCE [v27/v28]
# =============================================================================
try:
    from solar_cells_db import (CELLS, CELLULES_PHYSIQUE, CELLULES_BENCHMARK,
                                N_CELLS, REFERENCES_BIBLIOGRAPHIQUES,
                                poids_tc, poids_elec, poids_diode_v28,
                                rapport_provenance, normaliser_radiation,
                                fluence_equivalente_1MeV, get_rdc,
                                fluence_legacy, SEUIL_REJET as _SEUIL_REJET_DB,
                                RDC_MESURES, FACTEUR_LEGACY)
    SOURCE = "solar_cells_database.yaml (via solar_cells_db v28)"
    _HAS_PROV = True
    _HAS_F3 = True
    SEUIL_REJET = _SEUIL_REJET_DB
except Exception:
    from donnees_cellules_88 import (CELLS, CELLULES_PHYSIQUE, CELLULES_BENCHMARK,
                                     N_CELLS, REFERENCES_BIBLIOGRAPHIQUES)
    SOURCE = "donnees_cellules_88.py"
    _HAS_PROV = False
    _HAS_F3 = False
    SEUIL_REJET = 0.05
    RDC_MESURES = {}
    FACTEUR_LEGACY = 1e14
    def poids_tc(c): return (0.3, "repli")
    def poids_elec(c): return (1.0, "measured")
    def poids_diode_v28(c): return (0.0, "NON_IDENTIFIABLE")
    def rapport_provenance(): pass
    def normaliser_radiation(c): return []
    def fluence_equivalente_1MeV(r): return None
    def get_rdc(p, e): return None
    def fluence_legacy(c, i): return None

# =============================================================================
# [v28] IMPORT CONDITIONNEL DES MOTEURS PHYSIQUES AVANCÉS / ADVANCED PHYSICS
# =============================================================================
try:
    from models.config import (POIDS as POIDS_V28, STATUT_CANAL as STATUT_CANAL_V28,
                               fraction_restante as fraction_restante_v28,
                               dommage_total as dommage_total_v28,
                               resultat_non_identifiable as non_identifiable_v28)
    _HAS_V28_CONFIG = True
except Exception:
    _HAS_V28_CONFIG = False
    POIDS_V28 = {"datasheet":1.0,"analytique":0.8,"numerique":0.5,"estime":0.3,"inexistant":0.0}
    STATUT_CANAL_V28 = {"rad":"PARTIALLY_REVERSIBLE","thermal":"PRACTICALLY_IRREVERSIBLE",
                        "age":"PRACTICALLY_IRREVERSIBLE","opt":"PRACTICALLY_IRREVERSIBLE",
                        "mech":"FUNDAMENTALLY_IRREVERSIBLE","ESD":"FUNDAMENTALLY_IRREVERSIBLE",
                        "impact":"FUNDAMENTALLY_IRREVERSIBLE","TJ":"PRACTICALLY_IRREVERSIBLE"}
    def fraction_restante_v28(dom, p): return 1.0
    def dommage_total_v28(dom, p): return 0.0
    def non_identifiable_v28(mec, raison):
        return {"statut":"NON_IDENTIFIABLE","mecanisme":mec,"raison":raison,"poids_confiance":0.0}

try:
    from models.annealing_model import run_recuit as run_recuit_v28
    _HAS_V28_ANNEAL = True
except Exception:
    _HAS_V28_ANNEAL = False
    def run_recuit_v28(cfg): return non_identifiable_v28("recuit","Module models/ absent")

try:
    from models.thermal_model import vieillissement_thermal as vieill_therm_v28
    _HAS_V28_AGING = True
except Exception:
    _HAS_V28_AGING = False
    def vieill_therm_v28(T_hist, t_h, A=None, Ea_eV=None):
        return non_identifiable_v28("thermal_aging","Module models/ absent")

try:
    from models.impact_model import diametre_cratere as cratere_v28
    _HAS_V28_IMPACT = True
except Exception:
    _HAS_V28_IMPACT = False
    def cratere_v28(*args, **kw): return non_identifiable_v28("impact","Module models/ absent")

try:
    from models.tj_model import current_matching_3j as cm3j_v28
    _HAS_V28_TJ = True
except Exception:
    _HAS_V28_TJ = False
    def cm3j_v28(*args): return non_identifiable_v28("TJ","Module models/ absent")

try:
    from models.optical_model import degradation_optique as deg_opt_v28
    _HAS_V28_OPT = True
except Exception:
    _HAS_V28_OPT = False
    def deg_opt_v28(*args): return non_identifiable_v28("optique","Module models/ absent")

# =============================================================================
# 0. i18n — GESTION BILINGUE / BILINGUAL HANDLING
# =============================================================================
LANG = "both"
def set_lang(l):
    """[FR] Choisit la langue d'affichage. [EN] Sets display language."""
    global LANG; LANG = l if l in ("fr","en","both") else "both"

def tx(fr, en):
    """[FR] Retourne le texte selon LANG. [EN] Returns text per LANG."""
    if LANG == "fr": return fr
    if LANG == "en": return en
    return f"{fr} | {en}"

# Harmonise la clé fabricant / harmonize manufacturer key
for _c in list(CELLULES_PHYSIQUE) + list(CELLULES_BENCHMARK):
    if "fab" not in _c: _c["fab"] = _c.get("fabricant", "?")

# =============================================================================
# 1. CONSTANTES SI / SI CONSTANTS
# =============================================================================
K_B    = 1.380649e-23          # Boltzmann [J/K]
K_B_EV = 8.617333262e-5        # Boltzmann [eV/K]
Q      = 1.60217663e-19        # Charge électron [C]
S_REF  = 1367.0                # Irradiance AM0 standard [W/m²]
S1367  = 136.7                 # AM0 [mW/cm²]
S1353  = 135.3                 # AM0 variante ASTM [mW/cm²]
SEED   = 2026                  # Graine aléatoire reproductible
TOL    = 1e-9                  # Tolérance numérique
N_BOOTSTRAP, N_CORES = 200, 4
GRANDEURS = ("Voc", "Isc", "Vmp", "Imp")

# =============================================================================
# 2. KELVIN (vectorisé) & PLAGES & NORMES & PROFILS MISSION
# =============================================================================
def C2K(t): return np.asarray(t, dtype=float) + 273.15
def K2C(t): return np.asarray(t, dtype=float) - 273.15

T_REF_K = float(C2K(28.0))
TEMPERATURES_K = (float(C2K(28.0)), float(C2K(60.0)), float(C2K(100.0)))

PLAGES_TEMPERATURE = {
    "ECSS_QUALIFICATION": dict(T_min_C=-175.0, T_max_C=140.0,
        fr="Qualification ECSS (ESPC 2016)", en="ECSS qualification (ESPC 2016)",
        ref="Blanco et al., ESPC 2016, doi:10.1051/e3sconf/20171616002"),
    "ECSS_ROBUSTNESS": dict(T_min_C=-185.0, T_max_C=150.0,
        fr="Robustesse : extrêmes + 10 K", en="Robustness: extremes + 10 K",
        ref="ECSS-E-ST-20-08C Rev.2 §12.6.10"),
    "LUNE_GLOBAL": dict(T_min_C=-240.0, T_max_C=121.0,
        fr="Environnement lunaire", en="Lunar environment",
        ref="Paige et al., Space Sci. Rev. 150 (2010), LRO Diviner"),
    # [v28-CRYO] Plage cryogénique Deep Space
    "DEEP_SPACE_CRYO": dict(T_min_C=-200.0, T_max_C=-50.0,
        fr="Espace lointain cryogénique (JUICE)", en="Deep space cryogenic (JUICE)",
        ref="ESA JUICE Solar Array Design Studies"),
}

NORMES_REFERENCE = {
    "Europe":  "ECSS-E-ST-20-08C Rev.2 (20 avril 2023)",
    "USA":     "MIL-STD-810H (2019) + NASA-STD-8739",
    "Mission": "t1/t2 dans SCD-PVA (§12.6.9) / t1/t2 in SCD-PVA",
}

# [v28-CRYO] Profils de mission / Mission profiles
PROFILS_MISSION = {
    "LEO_STANDARD":  dict(distance_AU=1.0,  irradiance_W_m2=1367.0,
                         annealing=True,  diode_model="1-diode", damage_corr=1.0),
    "GEO_STANDARD":  dict(distance_AU=1.0,  irradiance_W_m2=1367.0,
                         annealing=True,  diode_model="1-diode", damage_corr=1.0),
    "JUICE_JUPITER": dict(distance_AU=5.2,  irradiance_W_m2=50.0,
                         annealing=False, diode_model="2-diode", damage_corr=1.25),
    "MARS_SURFACE":  dict(distance_AU=1.52, irradiance_W_m2=590.0,
                         annealing=False, diode_model="2-diode", damage_corr=1.10),
}

def statut_temperature(T_C, t1=140.0, t2=-175.0):
    """[FR] Statut ECSS de la température. [EN] ECSS temperature status."""
    if t2 <= T_C <= t1: return "QUALIFIE", tx("plage de qualification","qualification range")
    if (t2-10) <= T_C <= (t1+10): return "ROBUSTESSE", tx("robuste ECSS +10 K","ECSS robust +10 K")
    p = PLAGES_TEMPERATURE["LUNE_GLOBAL"]
    if p["T_min_C"] <= T_C <= p["T_max_C"]: return "LUNE", tx("lunaire","lunar")
    return "HORS_LIMITES", tx("hors limites — clipé","out of limits — clipped")

def temperature_pratique(T_C):
    """[FR] Clip à la plage physique globale (Lune). [EN] Clip to lunar range."""
    p = PLAGES_TEMPERATURE["LUNE_GLOBAL"]
    return float(np.clip(T_C, p["T_min_C"], p["T_max_C"]))

# =============================================================================
# 3. ÉTAT & PROGRESSION / GLOBAL STATE & PROGRESS
# =============================================================================
ETAT = dict(modeles={}, boot={}, deg_rows=[], diode_rows=[], boot_rows=[],
            bench_rows=[], syn_rows=[], validated=False, selection=None,
            cores=N_CORES, nboot=N_BOOTSTRAP, plot=True, last_fixes=[],
            mission_profile="LEO_STANDARD", dommages={}, fluence_cache={})

_SI = {"fait": False}

def normaliser_si(cells):
    """[FR] mV→V, mA→A (une fois) + T_ref_K + tc en SI. [EN] mV→V, mA→A (once)."""
    if _SI["fait"]: return
    for c in cells:
        if not c.get("complet"): continue
        for g in ("Voc","Vmp"): c[g] = np.asarray(c[g], float)/1000.0
        for g in ("Isc","Imp"): c[g] = np.asarray(c[g], float)/1000.0
        c["T_ref_K"] = float(C2K(c.get("T_ref", 28.0)))
        if c.get("tc"):
            for k in ("dVoc","dVmp"): c["tc"][k]=[x/1000. for x in c["tc"][k]]
            for k in ("dIsc","dImp"): c["tc"][k]=[x/1000. for x in c["tc"][k]]
    _SI["fait"] = True

try:
    from tqdm import tqdm; HAS_TQDM = True
except Exception:
    HAS_TQDM = False

class Bar:
    """[FR] Barre de progression texte. [EN] Text progress bar."""
    def __init__(self, total, label="", width=30):
        self.total=max(int(total),1); self.label=label; self.width=width
        self.t0=time.time(); self._draw(0)
    def step(self,i,suffix=""): self._draw(i,suffix)
    def _draw(self,i,suffix=""):
        f=min(i/self.total,1.); n=int(f*self.width)
        sys.stdout.write(f"\r  {self.label} [{'#'*n}{'-'*(self.width-n)}] "
                         f"{f*100:5.1f}% ({i}/{self.total}) {time.time()-self.t0:.1f}s {suffix}  ")
        sys.stdout.flush()
    def close(self): sys.stdout.write("\n"); sys.stdout.flush()

def progress(seq, label=""):
    """[FR] Itère avec barre. [EN] Iterate with progress bar."""
    if HAS_TQDM: yield from tqdm(seq, desc=label, ncols=90)
    else:
        b=Bar(len(seq),label)
        for i,x in enumerate(seq): yield x; b.step(i+1)
        b.close()

@contextmanager
def chrono(name):
    """[FR] Affiche début/fin + durée. [EN] Prints start/end + duration."""
    t0=time.time(); print(f"\n[{time.time()-t0:7.1f}s] >>> {name}")
    yield
    print(f"[{time.time()-t0:7.1f}s] <<< {name} {tx('terminé en','done in')} {time.time()-t0:.1f}s")

# =============================================================================
# 4. AGENTS MÉMOIRE & ARCHITECTE (THERMO SI + traçage repli [v27-S2])
# =============================================================================
class AgentMemoire:
    """[FR] Cache JSON (SHA-256) + gestion des variables fixées.
    [EN] SHA-256 JSON cache + fixed-variable management."""
    FIX_FILE = "fix_variables.json"
    def __init__(self, dossier="pv_memoire", actif=True):
        script_dir = Path(__file__).parent.resolve()
        self.d = script_dir / dossier; self.d.mkdir(exist_ok=True); self.actif=actif
        self.fm = self.d/"modeles.json"; self.fj = self.d/"journal.log"
        self.mod = json.loads(self.fm.read_text()) if self.fm.exists() else {}

    @staticmethod
    def hash_cell(c):
        h=hashlib.sha256()
        for k in ("Voc","Isc","Vmp","Imp","flu"):
            v = c.get(k)
            if v is not None: h.update(np.asarray(v,float).tobytes())
        return h.hexdigest()[:16]

    def lire(self,c,g):
        if not self.actif: return None
        m=self.mod.get(c.get("ref","?"),{}).get(g)
        return (m["C"],m["Phi0"],m["R2"]) if m and m.get("hash")==self.hash_cell(c) else None

    def sauver(self,c,g,C_,P_,R_):
        if not self.actif: return
        ref = c.get("ref","?")
        self.mod.setdefault(ref,{})[g]=dict(hash=self.hash_cell(c),
                                             C=float(C_),Phi0=float(P_),R2=float(R_))
        self.fm.write_text(json.dumps(self.mod,indent=1))

    def journal(self,m):
        with open(self.fj,"a",encoding="utf-8") as f: f.write(f"{time.strftime('%H:%M:%S')} | {m}\n")

    def fix_path(self): return self.d / self.FIX_FILE

    def lire_fix(self):
        p=self.fix_path()
        if not p.exists(): return {"actif":True,"fixations":[]}
        try: return json.loads(p.read_text())
        except Exception: return {"actif":True,"fixations":[]}

    def sauver_fix(self,data): self.fix_path().write_text(json.dumps(data,indent=1))

    def ajouter_fix(self,ref,variable,valeur,phi,T_C,S=1367.0,tol_phi=.05,tol_T=1.0,source=""):
        """[FR] Fixe une grandeur à une valeur externe. [EN] Anchor a quantity."""
        d=self.lire_fix()
        d["fixations"].append(dict(ref=ref,variable=variable,valeur=valeur,phi=phi,
                                   T_C=T_C,S=S,tol_phi=tol_phi,tol_T=tol_T,source=source))
        self.sauver_fix(d)

    def retirer_fix(self,index):
        d=self.lire_fix()
        if 0<=index<len(d["fixations"]): d["fixations"].pop(index); self.sauver_fix(d)

    def appliquer_fix(self,ref,out,phi,T_K,S):
        """[FR] Remplace les grandeurs fixées (conditions proches). [EN] Apply fixes."""
        d=self.lire_fix(); applied=[]
        if not d.get("actif",True): return out,applied
        for fx in d.get("fixations",[]):
            if fx.get("ref")!=ref: continue
            if abs(phi-fx["phi"])>fx.get("tol_phi",.05): continue
            if abs(T_K-(fx["T_C"]+273.15))>fx.get("tol_T",1.0): continue
            if "S" in fx and abs(S-fx["S"])>1e-6: continue
            if fx["variable"] in out:
                out[fx["variable"]]=float(fx["valeur"]); applied.append(fx["variable"])
        return out,applied

MEM = AgentMemoire()

def _SI_tc(d):
    """[FR] CORRECTIF 1 : mV/°C→V/K, mA/°C→A/K. [EN] mV/°C→V/K, mA/°C→A/K."""
    return dict(f=d["f"], **{k:[x/1000. for x in d[k]] for k in ("dVoc","dIsc","dVmp","dImp")})

class AgentArchitecte:
    """[FR] Validation + coeffs thermiques (SI) + traçage repli [v27-S2].
    [EN] Validation + SI thermal coeffs + fallback tracing [v27-S2]."""
    _THERMO_BRUT = {
        "TJ":  dict(f=[0,2.5,5,10],dVoc=[-6.2,-6.5,-6.6,-6.7],dIsc=[.36,.33,.35,.38],
                    dVmp=[-6.7,-6.8,-7.1,-7.2],dImp=[.24,.20,.24,.28]),
        "QJ":  dict(f=[0,2.5,5,10],dVoc=[-8.4,-8.5,-8.8,-8.9],dIsc=[.07,.103,.142,.142],
                    dVmp=[-8.6,-8.7,-9.0,-9.0],dImp=[.031,.048,.071,.071]),
        "Si":  dict(f=[0,3,10,30],dVoc=[-2.02,-2.14,-2.17,-2.20],dIsc=[.708,1.062,1.299,1.393],
                    dVmp=[-2.07,-2.22,-2.19,-2.25],dImp=[.85,1.0,1.2,1.3]),
        "CIGS":dict(f=[0,10],dVoc=[-6.,-6.],dIsc=[.1,.1],dVmp=[-6.,-6.],dImp=[.1,.1]),
    }
    THERMO = {k: _SI_tc(v) for k, v in _THERMO_BRUT.items()}  # [FIX 1] SI

    def coeffs(self,c):
        """[FR] Coeffs à la fluence + traçage du repli THERMO. [v27-S2]
        [EN] Coeffs at fluence + THERMO fallback tracing. [v27-S2]"""
        tc = c.get("tc")
        if tc and tc.get("f"):
            t = tc
        else:
            t = self.THERMO.get(c.get("tech","TJ"), self.THERMO["TJ"])
            ETAT.setdefault("fallback_thermo", set()).add(c.get("ref","?"))
            ETAT.setdefault("tc_provenance", {})[c.get("ref","?")] = \
                "datasheet" if (tc and tc.get("f")) else "repli THERMO"
        return {k:np.interp(c.get("flu",0),t["f"],t[k]) for k in ("dVoc","dIsc","dVmp","dImp")}

    @staticmethod
    def modele_diode(phi): return "1-diode+2R" if phi>=10 else "1-diode"

    def valider(self,cells):
        iss=[]
        for c in cells:
            if c.get("complet"):
                if np.any(np.diff(c.get("Voc",np.array([])))>0):
                    iss.append(f"{c.get('ref','?')}: Voc non décroissant/not decreasing")
            elif (c.get("eff",0) or 0)>40:
                iss.append(f"{c.get('ref','?')}: eff>40%")
        return iss

ARCH = AgentArchitecte()

# =============================================================================
# 5. PHYSIQUE / PHYSICS
# =============================================================================
def corriger_temperature(c,T_K,arch=ARCH):
    """[FR] X(T)≈X(Tref)+(dX/dT)·ΔT ; clip si hors limites. [EN] Linear thermal corr."""
    st,_=statut_temperature(float(K2C(T_K)))
    if st=="HORS_LIMITES": T_K=C2K(temperature_pratique(float(K2C(T_K))))
    k=arch.coeffs(c); dT=T_K-c.get("T_ref_K",T_REF_K); out={}
    for g in GRANDEURS:
        v=np.asarray(c.get(g,[0.0]),float)
        if abs(dT)>1e-12: v=v+k[{"Voc":"dVoc","Isc":"dIsc","Vmp":"dVmp","Imp":"dImp"}[g]]*dT
        out[g]=np.maximum(v,1e-9)
    return out

def corriger_irradiance(voc,isc,vmp,imp,ns,t_k,S):
    """[FR] Correction ECSS : Isc∝S ; Voc+=N_s·V_t·ln(S/S_ref). [EN] ECSS irradiance."""
    sr=max(S/S_REF,1e-6); vt=(ns*K_B*t_k)/Q
    isc_o=max(isc*sr,1e-9); voc_o=max(voc+vt*np.log(sr),1e-4)
    pmp_o=max(vmp*imp*sr,1e-9); vmp_o=min(max(vmp+vt*np.log(sr),1e-4),voc_o*.98)
    return voc_o,isc_o,vmp_o,min(max(pmp_o/vmp_o,1e-9),isc_o*.98)

# --- Loi de Tada [31] / Tada law ---
def eq_int(C,ai,bi,ak,bk):
    if abs(C)<1e-12 or abs(ai)<1e-12 or abs(ak)<1e-12: return np.inf
    ti=np.expm1(np.clip(ai/C,-100,100)); tk=np.expm1(np.clip(ak/C,-100,100))
    if abs(ti)<1e-15 or abs(tk)<1e-15: return np.inf
    return bi/ti-bk/tk

def evaluer(C,P0,v,f):
    if abs(P0)<1e-12: return None
    a=1+np.asarray(f)/P0
    if np.any(a<=0): return None
    p=v[0]*(1-C*np.log(a))
    if not np.all(np.isfinite(p)): return None
    ss=np.sum((v-p)**2); st=np.sum((v-v.mean())**2)
    return 1-ss/st if st>0 else 1.0

def C_conservateur(P0,v,f):
    """[FR] Projection conservative C*. [EN] Conservative projection C*."""
    a=1-np.asarray(v)/v[0]; lt=np.log(1+np.asarray(f,float)/P0); m=lt>1e-12
    return float(np.max(np.where(m,a/np.where(m,lt,1.),0.)))

def selection_conservatrice(v,f):
    """[FR] Extraction (C*,Φ₀,R²) analytique + projection. [EN] Analytic extraction."""
    x0=v[0]; a=1-np.asarray(v)/x0; b=np.asarray(f,float)
    idx=[i for i in range(len(a)) if abs(a[i])>1e-9]; sols=[]
    for lo0,hi0 in [(1e-5,.30),(-.30,-1e-5)]:
        for i,k in combinations(idx,2):
            g=np.linspace(lo0,hi0,200)
            for lo,hi in zip(g[:-1],g[1:]):
                fa,fb=eq_int(lo,a[i],b[i],a[k],b[k]),eq_int(hi,a[i],b[i],a[k],b[k])
                if np.isfinite(fa) and np.isfinite(fb) and fa*fb<=0:
                    try: cs=brentq(lambda C:eq_int(C,a[i],b[i],a[k],b[k]),lo,hi)
                    except Exception: continue
                    den=np.expm1(np.clip(a[i]/cs,-100,100))
                    if abs(den)<1e-15: continue
                    P0=b[i]/den; r2=evaluer(cs,P0,v,f)
                    if r2 is not None: sols.append((cs,P0,r2))
    phys=[s for s in sols if s[0]>0 and s[1]>0]
    if not phys:
        neg=[s for s in sols if s[0]<0 and s[1]<0]
        if not neg: return None
        bn=max(neg,key=lambda s:s[2]); phys=[(abs(bn[0]),abs(bn[1]),bn[2])]
    proj=[]
    for cs,P0,r2 in phys:
        cc=C_conservateur(P0,v,f); r=evaluer(cc,P0,v,f)
        if r is None or cc<=0: continue
        p=v[0]*(1-cc*np.log(1+np.asarray(f)/P0))
        if np.max((p-v)/v)<=TOL: proj.append((cc,P0,r))
    return max(proj,key=lambda s:s[2]) if proj else None

def construire_modele(c,T_K,arch=ARCH):
    ds=corriger_temperature(c,T_K,arch)
    return {"cell":c,"dataset":ds,
            "optima":{g:selection_conservatrice(ds[g],c.get("flu",np.array([0.0])))
                      for g in GRANDEURS}}

# [v28-F3] Cache fluence équivalente par cellule / Equivalent fluence cache
def get_fluence_equivalente(c):
    """[FR] Retourne la fluence équivalente 1 MeV e⁻ depuis radiation structurée.
    Cache le résultat pour éviter les recalculs.
    [EN] Returns 1 MeV e⁻ equivalent fluence from structured radiation."""
    ref = c.get("ref","?")
    if ref in ETAT["fluence_cache"]:
        return ETAT["fluence_cache"][ref]
    if not _HAS_F3:
        return None
    rad_list = c.get("radiation") or []
    if not rad_list:
        return None
    result = fluence_equivalente_1MeV(rad_list[0])
    ETAT["fluence_cache"][ref] = result
    return result

def predire_completes(c,modele,phi,T_K,S,arch=ARCH):
    """[FR] Prédit (Voc,Isc,Vmp,Imp) à (Φ,T,S) + applique variables fixées.
    [EN] Predicts at (Phi,T,S) + applies fixed variables."""
    ds=corriger_temperature(c,T_K,arch); out={}
    for g in GRANDEURS:
        x0=ds[g][0]; o=modele["optima"][g]
        if o is None: out[g]=x0
        else:
            ratio=1+phi/o[1]
            out[g]=max(x0*(1-o[0]*np.log(ratio)) if ratio>0 else x0, 1e-9)
    # Correction irradiance ECSS
    if abs(S-S_REF)>1e-6:
        out["Voc"],out["Isc"],out["Vmp"],out["Imp"]=corriger_irradiance(
            out["Voc"],out["Isc"],out["Vmp"],out["Imp"],c.get("N_s",3),T_K,S)
    out,applied=MEM.appliquer_fix(c.get("ref","?"),out,phi,T_K,S)
    ETAT["last_fixes"]=applied
    return out

# --- Diode 1-diode Lambert W [32,33] / 1-diode Lambert W ---
def extraire_diode_robuste(voc,isc,vmp,imp,t_k=T_REF_K,ns=3):
    """[FR] 1-diode (Lambert W), entrées SI. [EN] 1-diode (Lambert W), SI inputs."""
    v1=(K_B*t_k)/Q; best=(1e9,None)
    for nat in np.linspace(ns*.8,ns*2.5,60):
        vt=nat*v1
        if vt<1e-4: continue
        i0=isc/(np.exp(np.clip(voc/vt,-80,80))-1)
        if i0<=1e-20 or not np.isfinite(i0): continue
        ipv=isc+i0*(np.exp(np.clip(isc*.01/vt,-80,80))-1)
        al=1+(ipv-imp)/i0
        if al<=1: continue
        rs=(vt*np.log(al)-vmp)/imp
        if rs<1e-5 or rs>2: continue
        vv=np.linspace(0,voc,300)
        aw=(i0*rs/vt)*np.exp(np.clip((vv+(ipv+i0)*rs)/vt,-80,80))
        w=np.real(lambertw(np.nan_to_num(aw,nan=0.,posinf=1e8,neginf=-1/np.e)))
        iv=np.maximum(ipv+i0-(vt/rs)*w,0.); pv=vv*iv; im=int(np.argmax(pv))
        e=abs(pv[im]-vmp*imp)/(vmp*imp) if vmp*imp>0 else 1.0
        if e<best[0]: best=(e,dict(I_pv=ipv,I_0=i0,R_s=rs,N_a=nat/ns,P_max=pv[im]))
    return best[1]

# [v28-F5] Diode enrichie avec seuil de rejet + R_sh
def extraire_diode_v28(voc,isc,vmp,imp,t_k=T_REF_K,ns=3,iv_complete=None):
    """[v28-F5] Extraction diode avec seuil de rejet + R_sh optionnel.
    [EN] Diode extraction with rejection threshold + optional R_sh."""
    d = extraire_diode_robuste(voc,isc,vmp,imp,t_k,ns)
    if d is None:
        return {"statut":"NON_IDENTIFIABLE","raison":"Pas de solution physique",
                "poids_confiance":0.0}
    pmp_calcule = vmp*imp
    erreur = abs(d["P_max"]-pmp_calcule)/pmp_calcule if pmp_calcule>0 else 1.0
    if erreur > SEUIL_REJET:
        return {"statut":"REJETE","erreur":erreur,
                "raison":f"Erreur {erreur:.1%} > seuil {SEUIL_REJET:.0%}",
                "poids_confiance":0.0}
    # R_sh optionnel
    if iv_complete is not None:
        V_arr, I_arr = iv_complete
        n_pts = min(5, len(V_arr))
        if n_pts >= 2:
            pente = np.polyfit(V_arr[:n_pts], I_arr[:n_pts], 1)[0]
            d["R_sh"] = 1.0/pente if pente>0 else None
        else:
            d["R_sh"] = None
    else:
        d["R_sh"] = None
    poids = 1.0 if erreur<0.01 else (0.5 if erreur<SEUIL_REJET else 0.0)
    d["statut"]="actif"; d["erreur"]=erreur; d["poids_confiance"]=poids
    return d

# [v28-LLL] Diode 2-diodes pour Low Light Level
def extraire_diode_2d_v28(voc,isc,vmp,imp,t_k=T_REF_K,ns=3,iv_complete=None):
    """[v28-F5] Extraction 2-diodes pour LLL (< 200 W/m²).
    [EN] 2-diode extraction for LLL (< 200 W/m²)."""
    d = extraire_diode_v28(voc,isc,vmp,imp,t_k,ns,iv_complete)
    if d["statut"] != "actif": return d
    if iv_complete is not None:
        V_arr, I_arr = iv_complete
        vt = (K_B*t_k)/Q
        I_1diode = d["I_pv"] - d["I_0"]*(np.exp(np.clip((V_arr+I_arr*d["R_s"])/(d["N_a"]*ns*vt),-80,80))-1)
        residu = I_1diode - I_arr
        zone = (V_arr > voc*0.3) & (V_arr < voc*0.7)
        if np.any(zone):
            d["I_02"] = max(float(np.mean(np.abs(residu[zone]))),1e-20)
        else:
            d["I_02"] = None
    else:
        d["I_02"] = None
    d["modele"] = "2-diode LLL"
    return d

def courbe_iv(d,voc,t_k,ns):
    """[FR] Génère la courbe I-V complète. [EN] Generates full I-V curve."""
    v1=(K_B*t_k)/Q; vt=d["N_a"]*ns*v1
    vv=np.linspace(0,voc,400)
    aw=(d["I_0"]*d["R_s"]/vt)*np.exp(np.clip((vv+(d["I_pv"]+d["I_0"])*d["R_s"])/vt,-80,80))
    w=np.real(lambertw(np.nan_to_num(aw,nan=0.,posinf=1e8,neginf=-1/np.e)))
    iv=np.maximum(d["I_pv"]+d["I_0"]-(vt/d["R_s"])*w,0.)
    return vv,iv,vv*iv

# --- Calibration à R_s fixé (module [15]) / fixed-Rs calibration ---
def _i0_ipv_pour_n(n,voc,isc,rs,t_k):
    vt=n*(K_B*t_k)/Q
    E_voc=np.exp(np.clip(voc/vt,-80,80)); E_isc=np.exp(np.clip(isc*rs/vt,-80,80))
    den=E_voc-E_isc
    if den<=0: return None,None,vt
    I0=isc/den; Ipv=I0*(E_voc-1)
    return I0,Ipv,vt

def caler_diode_rs_fixe(voc,isc,vm,im,rs,t_k=T_REF_K,ns=3,n_lo=None,n_hi=None):
    """[FR] R_s fixé + (Vmpp,Impp) imposé → (I_pv,I₀,N_a). [EN] Fixed Rs + MPP."""
    n_lo=n_lo or .5*ns; n_hi=n_hi or 3.*ns
    def residu(n):
        I0,Ipv,vt=_i0_ipv_pour_n(n,voc,isc,rs,t_k)
        if I0 is None: return np.inf
        E_m=np.exp(np.clip((vm+im*rs)/vt,-80,80))
        return Ipv-I0*(E_m-1)-im
    g=np.linspace(n_lo,n_hi,200); fg=np.array([residu(x) for x in g])
    idx=np.where(np.diff(np.sign(fg))!=0)[0]
    if len(idx)==0: return None
    n_sol=brentq(residu,g[idx[0]],g[idx[0]+1])
    I0,Ipv,vt=_i0_ipv_pour_n(n_sol,voc,isc,rs,t_k)
    return dict(I_pv=Ipv,I_0=I0,R_s=rs,N_a=n_sol/ns)

def caler_diode_pmax(voc,isc,pmax,rs,t_k=T_REF_K,ns=3):
    """[FR] Calibration avec Pmax imposé. [EN] Calibration with imposed Pmax."""
    def _obj(vm):
        im=pmax/vm if vm>0 else 0
        return caler_diode_rs_fixe(voc,isc,vm,im,rs,t_k,ns)
    best=None; best_err=1e9
    for vm in np.linspace(voc*0.5,voc*0.95,50):
        d=_obj(vm)
        if d is None: continue
        p=d["I_pv"]*vm
        err=abs(p-pmax)
        if err<best_err: best_err=err; best=d
    return best

# =============================================================================
# 6. MULTICŒUR + BOOTSTRAP / MULTICORE + BOOTSTRAP
# =============================================================================
def run_parallel(func,tasks,n_jobs):
    if n_jobs<=1 or len(tasks)<=1: return [func(t) for t in tasks]
    try:
        with ProcessPoolExecutor(max_workers=n_jobs) as ex: return list(ex.map(func,tasks))
    except Exception: return [func(t) for t in tasks]

def _w_diode(args):
    c,phi,T_K,S=args
    m=construire_modele(c,T_K); p=predire_completes(c,m,phi,T_K,S)
    # [v28-F5] Choix du modèle selon irradiance mission
    pm = PROFILS_MISSION.get(ETAT.get("mission_profile","LEO_STANDARD"), PROFILS_MISSION["LEO_STANDARD"])
    if pm["irradiance_W_m2"] < 200.0:
        d = extraire_diode_2d_v28(p["Voc"],p["Isc"],p["Vmp"],p["Imp"],T_K,c.get("N_s",3))
    else:
        d = extraire_diode_v28(p["Voc"],p["Isc"],p["Vmp"],p["Imp"],T_K,c.get("N_s",3))
    return dict(ref=c.get("ref","?"),phi=phi,T_K=T_K,d=d)

def _w_boot(args):
    ref,T_K,n_iter,seed=args; c=CELLS.get(ref,{})
    f=np.asarray(c.get("flu",[0.0]),float)
    out={g:{"C":[],"P":[]} for g in GRANDEURS}; rng=np.random.default_rng(seed)
    for _ in range(n_iter):
        idx=np.sort(rng.integers(1,len(f),len(f)-1))
        for g in GRANDEURS:
            v=np.concatenate([[c[g][0]],c[g][idx]])
            ff=np.concatenate([[f[0]],f[idx]])
            o=selection_conservatrice(v,ff)
            if o: out[g]["C"].append(o[0]); out[g]["P"].append(o[1])
    return out

def analyser_bootstrap(ref,T_K,n_iter,n_jobs):
    base,rem=divmod(n_iter,n_jobs)
    tasks=[(ref,T_K,base+(1 if i<rem else 0),SEED+i) for i in range(n_jobs) if (base+(1 if i<rem else 0))>0]
    merged={g:{"C":[],"P":[]} for g in GRANDEURS}
    for r in run_parallel(_w_boot,tasks,n_jobs):
        for g in GRANDEURS: merged[g]["C"]+=r[g]["C"]; merged[g]["P"]+=r[g]["P"]
    return {g:{"C":np.array(merged[g]["C"]),"P":np.array(merged[g]["P"])} for g in GRANDEURS}

# =============================================================================
# 7. MODULES 1-16 / MODULES 1-16
# =============================================================================
def selection_cellules():
    if ETAT["selection"] is None: ETAT["selection"]=list(CELLULES_PHYSIQUE)
    return ETAT["selection"]

def get_modele(ref):
    c=CELLS.get(ref)
    if c is None: return None
    if "T_ref_K" not in c: c["T_ref_K"]=float(C2K(c.get("T_ref",28.0)))
    if ref not in ETAT["modeles"]: ETAT["modeles"][ref]=construire_modele(c,c["T_ref_K"])
    return ETAT["modeles"][ref]

def run_data():
    """[1] [FR] Charger & valider + provenance. [EN] Load & validate + provenance."""
    normaliser_si(CELLULES_PHYSIQUE)
    iss=ARCH.valider(CELLS.values()); ETAT["validated"]=True
    print(f"🏛️ {tx('Architecte','Architect')}: {N_CELLS} {tx('cellules','cells')} "
          f"(phys={len(CELLULES_PHYSIQUE)}, bench={len(CELLULES_BENCHMARK)}); "
          f"{len(iss)} {tx('anomalie(s)','issue(s)')}.")
    for i in iss: print("   ⚠️ ",i)
    rapport_provenance()
    fb = ETAT.get("fallback_thermo", set())
    if fb:
        MEM.journal(f"ATTENTION repli THERMO (poids 0.30): {sorted(fb)}")
        print(f"   ⚠️ Repli THERMO générique : {', '.join(sorted(fb))}")
    # [v28-F3] Statut radiation structurée
    if _HAS_F3:
        n_rad = sum(1 for c in CELLULES_PHYSIQUE if c.get("radiation"))
        print(f"   🔬 F3 Radiation structurée : {n_rad}/{len(CELLULES_PHYSIQUE)} cellules")

def run_deg():
    """[2] [FR] Dégradation (C*,Φ₀) + Mémoire. [EN] Degradation (C*,Phi0) + Memory."""
    ETAT["deg_rows"]=[]
    for c in progress(selection_cellules(), tx("Dégradation","Degradation")):
        m=get_modele(c.get("ref","?"))
        if m is None: continue
        for g in GRANDEURS:
            o=m["optima"][g]
            if o is None:
                s=selection_conservatrice(m["dataset"][g],c.get("flu",np.array([0.0])))
                if s: o=s; MEM.sauver(c,g,*s); m["optima"][g]=o
            if o: ETAT["deg_rows"].append(dict(Ref=c.get("ref","?"),G=g,C=o[0],Phi0=o[1],R2=o[2]))
    print(pd.DataFrame(ETAT["deg_rows"]).to_string(index=False))

def run_boot():
    """[3] [FR] Bootstrap UQ. [EN] Bootstrap UQ."""
    ETAT["boot_rows"]=[]; ETAT["boot"]={}
    for c in progress(selection_cellules(),"Bootstrap"):
        b=analyser_bootstrap(c.get("ref","?"),c.get("T_ref_K",T_REF_K),ETAT["nboot"],ETAT["cores"])
        ETAT["boot"][c.get("ref","?")]=b
        for g in GRANDEURS:
            if b[g]["C"].size:
                ETAT["boot_rows"].append(dict(Ref=c.get("ref","?"),G=g,
                    C_moy=b[g]["C"].mean(),C_std=b[g]["C"].std(),
                    P_moy=b[g]["P"].mean(),P_std=b[g]["P"].std()))
    print(f"✅ Bootstrap: {len(ETAT['boot_rows'])} {tx('lignes UQ','UQ rows')}.")

def run_diode():
    """[4] [FR] Diode Lambert W multi-T. [EN] Lambert W diode multi-T."""
    ETAT["diode_rows"]=[]
    for c in selection_cellules():
        phis=np.unique(np.concatenate([np.asarray(c.get("flu",[0.0]),float),[0,1,10,100]]))
        for r in run_parallel(_w_diode,[(c,p,c.get("T_ref_K",T_REF_K),S_REF) for p in phis],ETAT["cores"]):
            d=r["d"]
            if d is None: continue
            if d.get("statut") == "REJETE":
                print(f"   ⚠️ {r['ref']} Φ={r['phi']}: REJETÉ (erreur={d.get('erreur',0):.1%})")
                continue
            if d.get("statut") != "actif": continue
            ETAT["diode_rows"].append(dict(Ref=r["ref"],Phi=r["phi"],
                I_pv=d["I_pv"],I_0=d["I_0"],R_s=d["R_s"],N_a=d["N_a"],
                P_max=d["P_max"],Modele=d.get("modele",ARCH.modele_diode(r["phi"])),
                R_sh=d.get("R_sh"),Erreur=d.get("erreur"),Poids=d.get("poids_confiance")))
    print(f"✅ {tx('Diode','Diode')}: {len(ETAT['diode_rows'])} {tx('extractions','extractions')}.")

def run_tests():
    """[5] [FR] Auto-tests T1-T5. [EN] Self-tests T1-T5."""
    for c in selection_cellules():
        m=get_modele(c.get("ref","?"))
        if m is None: continue
        b=ETAT["boot"].get(c.get("ref","?"))
        if b is None: b=analyser_bootstrap(c.get("ref","?"),c.get("T_ref_K",T_REF_K),ETAT["nboot"],ETAT["cores"])
        f=np.asarray(c.get("flu",[0.0]),float)
        print(f"\n--- SELF-TESTS: {c.get('ref','?')} ---")
        p0=predire_completes(c,m,0.,c.get("T_ref_K",T_REF_K),S_REF)
        d=extraire_diode_v28(p0["Voc"],p0["Isc"],p0["Vmp"],p0["Imp"],c.get("T_ref_K",T_REF_K),c.get("N_s",3))
        if d.get("statut")=="actif":
            e=d.get("erreur",1.0)
            print(f"  T1 MPP diode          : {'PASS' if e<0.02 else 'FAIL'} ({e:.2%}, poids={d.get('poids_confiance',0):.1f})")
        elif d.get("statut")=="REJETE":
            print(f"  T1 MPP diode          : REJETÉ (erreur={d.get('erreur',0):.2%} > {SEUIL_REJET:.0%})")
        else:
            print(f"  T1 MPP diode          : NON_IDENTIFIABLE ({d.get('raison','')})")
        viol=sum(predire_completes(c,m,f[i],c.get("T_ref_K",T_REF_K),S_REF)[g]>m["dataset"][g][i]*(1+TOL)
                 for g in GRANDEURS for i in range(len(f)))
        print(f"  T2 {tx('Jamais au-dessus','Never above'):20s}: {'PASS' if viol==0 else 'FAIL'}")
        pl=predire_completes(c,m,10.,c.get("T_ref_K",T_REF_K),1000.)
        ph=predire_completes(c,m,10.,c.get("T_ref_K",T_REF_K),S_REF)
        print(f"  T3 P(S) {tx('croissant','increasing'):16s}: "
              f"{'PASS' if ph['Vmp']*ph['Imp']>pl['Vmp']*pl['Imp'] else 'FAIL'}")
        pc=predire_completes(c,m,10.,c.get("T_ref_K",T_REF_K),S_REF)
        phh=predire_completes(c,m,10.,C2K(100.),S_REF)
        print(f"  T4 P(T) {tx('décroissant','decreasing'):16s}: "
              f"{'PASS' if pc['Vmp']*pc['Imp']>phh['Vmp']*phh['Imp'] else 'FAIL'}")
        if len(f)<2:
            print(f"  T5 Bootstrap           : PASS (BOL only / 1 fluence)")
        else:
            ok=all(b[g]["C"].size>20 for g in GRANDEURS) if b else False
            print(f"  T5 Bootstrap           : {'PASS' if ok else 'FAIL'}")

def run_fig():
    """[6] [FR] Figures. [EN] Figures."""
    for c in selection_cellules():
        m=get_modele(c.get("ref","?"))
        if m is None: continue
        b=ETAT["boot"].get(c.get("ref","?")) or {g:{"C":np.array([]),"P":np.array([])} for g in GRANDEURS}
        fig_degradation(m,b,c); fig_diode_vs_fluence(c)
        fig_iv_pv_TS(c,m); fig_pmax_vs_T(c,m)
    if ETAT["plot"]: plt.show()

def run_bench():
    """[7] [FR] Benchmark 59 BOL. [EN] Benchmark 59 BOL."""
    ETAT["bench_rows"]=[]
    for c in CELLULES_BENCHMARK:
        eff=c.get("eff"); flag=c.get("flag",False)
        warn = flag or (eff is not None and eff>40)  # [FIX 2]
        ETAT["bench_rows"].append(dict(Ref=c.get("ref","?"),Fabricant=c.get("fab"),
            Technologie=c.get("tech"),Eff=eff,
            Statut="WARNING" if warn else "OK",
            Note=c.get("note","")))
    n_warn=sum(1 for r in ETAT["bench_rows"] if r["Statut"]=="WARNING")
    print(f"📊 Benchmark: {len(ETAT['bench_rows'])} cellules, {n_warn} WARNING (eff>40% ou flag).")

def run_export():
    """[8] [FR] Export Excel. [EN] Export Excel."""
    if not ETAT["deg_rows"]: run_deg()
    if not ETAT["diode_rows"]: run_diode()
    if not ETAT["bench_rows"]: run_bench()
    ETAT["syn_rows"]=[dict(Ref=c.get("ref","?"),
                           P_BOL=c.get("Vmp",np.array([0]))[0]*c.get("Imp",np.array([0]))[0],
                           P_EOL=c.get("Vmp",np.array([0]))[-1]*c.get("Imp",np.array([0]))[-1])
                      for c in selection_cellules()]
    with pd.ExcelWriter("pv_jumeau_db.xlsx",engine="openpyxl") as xw:
        pd.DataFrame(ETAT["deg_rows"]).to_excel(xw,"Degradation",index=False)
        pd.DataFrame(ETAT["diode_rows"]).to_excel(xw,"Diode",index=False)
        pd.DataFrame(ETAT["boot_rows"]).to_excel(xw,"Bootstrap",index=False)
        pd.DataFrame(ETAT["bench_rows"]).to_excel(xw,f"Benchmark{len(ETAT['bench_rows'])}",index=False)  # [FIX 3]
        pd.DataFrame(ETAT["syn_rows"]).to_excel(xw,"Synthese",index=False)
    print("💾 pv_jumeau_db.xlsx "+tx("écrit (5 feuilles)","written (5 sheets)")+".")

def run_temp():
    """[13] [FR] Plages & normes. [EN] Ranges & standards."""
    print("\n🌡️ "+tx("PLAGES & NORMES (kelvin)","RANGES & STANDARDS (kelvin)"))
    for k,v in PLAGES_TEMPERATURE.items():
        print(f"  [{k}] {v['T_min_C']:+.0f}→{v['T_max_C']:+.0f}°C | "
              f"{tx(v['fr'],v['en'])} | {v['ref']}")
    for k,v in NORMES_REFERENCE.items(): print(f"  {k}: {v}")
    t=input("\n"+tx("Tester une T (°C) [enter=skip]: ","Test a T (°C) [enter=skip]: ")).strip()
    if t:
        st,msg=statut_temperature(float(t)); print(f"  → [{st}] {msg}")

def run_custom():
    """[14] [FR] Extraction (T,Φ). [EN] Extraction (T,Phi)."""
    print("\n"+tx("Cellules physiques:","Physical cells:"))
    for i,c in enumerate(CELLULES_PHYSIQUE): print(f"  {i:2d}. {c.get('ref','?')}")
    idx=int(input("  "+tx("Indice [0]: ","Index [0]: ")).strip() or 0)
    c=CELLULES_PHYSIQUE[min(idx,len(CELLULES_PHYSIQUE)-1)]
    while True:
        t_c=float(input("  T (°C) [28]: ").strip() or 28)
        phi=float(input("  Φ (E14) [10]: ").strip() or 10)
        s_w=float(input("  S (W/m²) [1367]: ").strip() or 1367)
        st,msg=statut_temperature(t_c); print(f"  [{st}] {msg}")
        T_K=C2K(temperature_pratique(t_c)) if st=="HORS_LIMITES" else C2K(t_c)
        m=construire_modele(c,T_K); p=predire_completes(c,m,phi,T_K,s_w)
        pm = PROFILS_MISSION.get(ETAT.get("mission_profile","LEO_STANDARD"), PROFILS_MISSION["LEO_STANDARD"])
        if pm["irradiance_W_m2"] < 200.0:
            d=extraire_diode_2d_v28(p["Voc"],p["Isc"],p["Vmp"],p["Imp"],T_K,c.get("N_s",3))
        else:
            d=extraire_diode_v28(p["Voc"],p["Isc"],p["Vmp"],p["Imp"],T_K,c.get("N_s",3))
        print(f"\n  {c.get('ref','?')}  T={t_c:+.1f}°C  Φ={phi:g}E14  S={s_w:.0f}")
        print(f"  Voc={p['Voc']:.3f}V  Isc={p['Isc']*1e3:.1f}mA  "
              f"Vmp={p['Vmp']:.3f}V  Imp={p['Imp']*1e3:.1f}mA")
        if ETAT["last_fixes"]: print(f"  🔧 {tx('fixées','fixed')}: {ETAT['last_fixes']}")
        if d and d.get("statut")=="actif":
            print(f"  I_pv={d['I_pv']*1e3:.2f}mA  I0={d['I_0']:.3e}A  "
                  f"Rs={d['R_s']*1e3:.3f}mΩ  N_a={d['N_a']:.3f}  Pmax={d['P_max']:.4f}W")
            if d.get("R_sh") is not None:
                print(f"  R_sh={d['R_sh']:.1f}Ω  Erreur={d.get('erreur',0)*100:.2f}%  "
                      f"Poids={d.get('poids_confiance',0):.1f}")
        elif d:
            print(f"  ❌ Diode: {d.get('statut','?')} — {d.get('raison','')}")
        if input("  "+tx("Refaire? (o/n) [n]: ","Redo? (y/n) [n]: ")).strip().lower() not in ("o","y"): break

def run_caler():
    """[15] [FR] Calibration R_s fixé. [EN] Fixed-Rs calibration."""
    print("\n"+tx("Cellules physiques:","Physical cells:"))
    for i,c in enumerate(CELLULES_PHYSIQUE): print(f"  {i:2d}. {c.get('ref','?')}")
    idx=int(input("  "+tx("Indice [0]: ","Index [0]: ")).strip() or 0)
    c=CELLULES_PHYSIQUE[min(idx,len(CELLULES_PHYSIQUE)-1)]
    t_c=float(input("  T (°C) [28]: ").strip() or 28)
    phi=float(input("  Φ (E14) [10]: ").strip() or 10)
    T_K=C2K(t_c)
    m=construire_modele(c,T_K); p=predire_completes(c,m,phi,T_K,S_REF)
    rs=float(input(f"  R_s (Ω) [0.01]: ").strip() or 0.01)
    mode=input("  Mode (vmpp/pmax) [vmpp]: ").strip().lower()
    if mode=="vmpp":
        vm=float(input("  Vmpp: ").strip() or f"{p['Vmp']:.3f}")
        im=float(input("  Impp: ").strip() or f"{p['Imp']:.3f}")
        d=caler_diode_rs_fixe(p["Voc"],p["Isc"],vm,im,rs,T_K,c.get("N_s",3))
    else:
        pm_val=float(input("  Pmax: ").strip() or f"{p['Vmp']*p['Imp']:.4f}")
        d=caler_diode_pmax(p["Voc"],p["Isc"],pm_val,rs,T_K,c.get("N_s",3))
    print(f"\n  {c.get('ref','?')}  Φ={phi:g}E14  T={t_c:+.1f}°C  Rs={rs:.4f}Ω")
    if d: print(f"  → I_pv={d['I_pv']*1e3:.2f}mA  I0={d['I_0']:.3e}A  N_a={d['N_a']:.3f}")
    else: print("  ❌ "+tx("pas de solution physique","no physical solution"))

def run_fix():
    """[16] [FR] Gère les variables fixées. [EN] Manage fixed variables."""
    while True:
        d=MEM.lire_fix()
        print("\n"+tx("Variables fixées (pv_memoire/fix_variables.json):",
                      "Fixed variables:"))
        if not d["fixations"]: print("  ("+tx("aucune","none")+")")
        for i,fx in enumerate(d["fixations"]):
            print(f"  [{i}] {fx['ref']} {fx['variable']}={fx['valeur']} "
                  f"@ Φ={fx['phi']}E14, T={fx['T_C']}°C ({fx.get('source','')})")
        ch=input("  "+tx("(a)jouter/(r)etirer/(q)uitter: ","(a)dd/(r)emove/(q)uit: ")).strip().lower()
        if ch=="a":
            ref=input("  ref: ").strip(); var=input("  variable (Voc/Isc/Vmp/Imp): ").strip()
            val=float(input("  valeur (V ou A): ")); phi=float(input("  Φ (E14): "))
            t_c=float(input("  T (°C) [28]: ").strip() or 28)
            src=input("  source [optionnel]: ").strip()
            MEM.ajouter_fix(ref,var,val,phi,t_c,source=src)
            print(f"  ✅ {tx('ajouté','added')}")
        elif ch=="r":
            i=int(input("  index: ").strip() or -1)
            MEM.retirer_fix(i); print(f"  ✅ {tx('retiré','removed')}")
        elif ch=="q": break

# =============================================================================
# 8. [v28] MODULES 17-25 / MODULES 17-25
# =============================================================================
def run_dommage_total():
    """[17] [M22] [FR] Dommage total 8 canaux. [EN] Total damage 8 channels."""
    for c in selection_cellules():
        BOL = {g: float(np.asarray(c.get(g,[0.0]),float)[0]) for g in GRANDEURS}
        dommages = ETAT.get("dommages", {}).get(c.get("ref","?"), {"rad": 0.10})
        dom_valides = {k:v for k,v in dommages.items() if v is not None and k in STATUT_CANAL_V28}
        if not dom_valides:
            print(f"  {c.get('ref','?')}: NON_IDENTIFIABLE (aucun canal)")
            continue
        params_degrades = {}
        for g in GRANDEURS:
            params_degrades[g] = BOL[g] * fraction_restante_v28(dom_valides, g)
        if params_degrades["Voc"]*params_degrades["Isc"] > 0:
            params_degrades["FF"] = (params_degrades["Vmp"]*params_degrades["Imp"]) / \
                                    (params_degrades["Voc"]*params_degrades["Isc"])
        else:
            params_degrades["FF"] = None
        params_degrades["Pmp"] = params_degrades["Vmp"] * params_degrades["Imp"]
        d_totaux = {p: dommage_total_v28(dom_valides, p) for p in GRANDEURS}
        print(f"\n  {c.get('ref','?')} — Canaux actifs: {list(dom_valides.keys())}")
        print(f"    Voc: {BOL['Voc']:.3f} → {params_degrades['Voc']:.3f} V")
        print(f"    Isc: {BOL['Isc']*1e3:.1f} → {params_degrades['Isc']*1e3:.1f} mA")
        print(f"    Pmp: {BOL['Vmp']*BOL['Imp']:.4f} → {params_degrades['Pmp']:.4f} W")
        print(f"    D_total(Pmp): {d_totaux.get('Pmp',0)*100:.2f}%")
        print(f"    Réparables: {[k for k in dom_valides if STATUT_CANAL_V28.get(k)=='PARTIALLY_REVERSIBLE']}")
        print(f"    Permanents: {[k for k in dom_valides if STATUT_CANAL_V28.get(k)!='PARTIALLY_REVERSIBLE']}")

def run_recuit():
    """[18] [M18] [FR] Recuit & récupération. [EN] Annealing & recovery."""
    mp_name = ETAT.get("mission_profile","LEO_STANDARD")
    mp = PROFILS_MISSION.get(mp_name, PROFILS_MISSION["LEO_STANDARD"])
    print(f"\n  Profil mission: {mp_name}")
    print(f"  Recuit actif: {mp['annealing']}")
    if not mp["annealing"]:
        print(f"  ⚠️ {tx('Recuit désactivé (cryogénique)','Annealing disabled (cryogenic)')}")
        return
    cfg = {
        "actif": True, "type_recuit": "arrhenius", "t_h": 100.0,
        "T_profil": [[0, 300.0], [50, 350.0], [100, 300.0]],
        "familles": [{"nom": "E1", "A": 1e9, "Ea": 0.85, "D0": 1.0}],
    }
    res = run_recuit_v28(cfg)
    if res.get("statut") == "actif":
        print(f"  Récupération: {res['recuperation_pct']:.1f}%")
        print(f"  D_rad final: {res['D_rad_final']:.4f}")
    else:
        print(f"  ❌ {res.get('raison','UNKNOWN')}")

def run_vieillissement():
    """[19] [M19] [FR] Vieillissement thermique. [EN] Thermal aging."""
    res = vieill_therm_v28([300.0]*100, 8760.0)
    if res.get("statut") == "actif":
        print(f"  D_thermal: {res['D_thermal']:.4f} (PERMANENT)")
    else:
        print(f"  ❌ {res.get('raison','UNKNOWN')}")

def run_impacts():
    """[20] [M20] [FR] Impacts & ESD. [EN] Impacts & ESD."""
    res_c = cratere_v28(0.001, 2.5, 10.0, 2.5)
    if res_c.get("statut") == "actif":
        print(f"  Cratère Dco: {res_c['Dco_cm']*1e4:.1f} µm (PERMANENT)")
    else:
        print(f"  ❌ {res_c.get('raison','UNKNOWN')}")
    # ESD : Q = I²Rt
    Q_esd = 1.0**2 * 10.0 * 1e-3
    print(f"  ESD énergie: {Q_esd:.4f} J (PERMANENT)")

def run_rdc():
    """[21] [M21] [FR] RDC / fluence équivalente. [EN] RDC / equivalent fluence."""
    if not _HAS_F3:
        print("  ❌ solar_cells_db v28 requis pour F3")
        return
    flu = float(input("  Fluence (E14 p+/cm²) [1]: ").strip() or 1) * 1e14
    e_mev = float(input("  Énergie (MeV) [3]: ").strip() or 3)
    rdc = get_rdc("proton", e_mev)
    if rdc is not None:
        flu_eq = flu * rdc
        print(f"  Φ_eq(1MeV) = {flu_eq:.3e} e/cm²")
        print(f"  RDC = {rdc}")
    else:
        print(f"  ❌ RDC NON_IDENTIFIABLE pour {e_mev} MeV")

def run_tj():
    """[23] [M23] [FR] Sous-cellules 3J. [EN] 3J subcells."""
    print("  Courants sous-cellules (mA) — entrer 0 si UNKNOWN:")
    i_top = float(input("  Isc top (GaInP) [180]: ").strip() or 180) / 1000
    i_mid = float(input("  Isc middle (GaAs) [175]: ").strip() or 175) / 1000
    i_bot = float(input("  Isc bottom (Ge) [190]: ").strip() or 190) / 1000
    res = cm3j_v28(i_top, i_mid, i_bot)
    if res.get("statut") == "actif":
        print(f"  Isc_3J = {res['Isc_3J']*1e3:.1f} mA")
        print(f"  Sous-cellule limitante: {res['sous_cellule_limitante']}")
    else:
        print(f"  ❌ {res.get('raison','UNKNOWN')}")

def run_optique():
    """[24] [M24] [FR] Dégradation optique. [EN] Optical degradation."""
    t_bol = float(input("  T_BOL [0.95]: ").strip() or 0.95)
    t_eol = float(input("  T_EOL [0.90]: ").strip() or 0.90)
    res = deg_opt_v28(t_bol, t_eol)
    if res.get("statut") == "actif":
        print(f"  D_opt = {res['D_opt']:.4f} (PERMANENT)")
    else:
        print(f"  ❌ {res.get('raison','UNKNOWN')}")

def run_mission_profile():
    """[25] [v28-CRYO] [FR] Sélection profil mission. [EN] Mission profile selection."""
    print("\n  Profils disponibles / Available profiles:")
    for k,v in PROFILS_MISSION.items():
        print(f"  [{k}] S={v['irradiance_W_m2']} W/m², T={v.get('T_typ_K','')} K, "
              f"annealing={v['annealing']}, diode={v['diode_model']}")
    ch = input("  Choix [LEO_STANDARD]: ").strip() or "LEO_STANDARD"
    if ch in PROFILS_MISSION:
        ETAT["mission_profile"] = ch
        mp = PROFILS_MISSION[ch]
        print(f"  ✅ Profil activé: {ch}")
        if not mp["annealing"]:
            print(f"  ⚠️ Recuit désactivé (cryogénique) / Annealing disabled (cryogenic)")
        if mp["diode_model"] == "2-diode":
            print(f"  ⚡ Mode 2-diodes LLL activé / LLL 2-diode mode activated")
        if mp["damage_corr"] != 1.0:
            print(f"  ⚠️ Facteur correction dommage: ×{mp['damage_corr']}")
    else:
        print(f"  ❌ Profil inconnu: {ch}")

# =============================================================================
# 9. FIGURES / FIGURES
# =============================================================================
def fig_degradation(modele,boot,c):
    fg=np.concatenate([np.linspace(0,1e-2,20),np.logspace(-2,4,500)])
    fig,axes=plt.subplots(2,2,figsize=(14,9),dpi=150)
    for ax,g in zip(axes.flatten(),GRANDEURS):
        v=modele["dataset"][g]; o=modele["optima"][g]
        ax.scatter(c.get("flu",np.array([0.0])),v,color="k",s=50,zorder=5,label="Data")
        if o:
            pr=v[0]*(1-o[0]*np.log(1+fg/o[1])); pr[~np.isfinite(pr)]=np.nan
            ax.plot(fg,pr,"crimson",lw=2,label=f"C*={o[0]:.3e}")
        if boot[g]["C"].size:
            b=np.nanpercentile(v[0]*(1-boot[g]["C"][:,None]*np.log(1+fg[None,:]/boot[g]["P"][:,None])),
                               [2.5,97.5],axis=0)
            ax.fill_between(fg,b[0],b[1],color="dodgerblue",alpha=.2,label="IC 95%")
        ax.set_xscale("symlog",linthresh=1e-2); ax.set_xlim(0,1e4)
        ax.set_title(g,fontweight="bold"); ax.grid(ls=":",alpha=.6); ax.legend(fontsize=8)
    fig.suptitle(tx(f"Dégradation conservative — {c.get('ref','?')}",
                    f"Conservative degradation — {c.get('ref','?')}"),fontweight="bold")
    fig.tight_layout()

def fig_diode_vs_fluence(c):
    phi=np.concatenate([[0.],np.logspace(np.log10(.5),2.,15)]); rows=[]
    for T_K in TEMPERATURES_K:
        m=construire_modele(c,T_K)
        for p in phi:
            st=predire_completes(c,m,p,T_K,S_REF)
            d=extraire_diode_v28(st["Voc"],st["Isc"],st["Vmp"],st["Imp"],T_K,c.get("N_s",3))
            if d and d.get("statut")=="actif":
                rows.append(dict(T=K2C(T_K),phi=p,I_pv=d["I_pv"],I_0=d["I_0"],
                                 Rs=d["R_s"]*1e3,N_a=d["N_a"]))
    if not rows: return
    df=pd.DataFrame(rows); fig,axes=plt.subplots(2,2,figsize=(13,8),dpi=150)
    for ax,(col,yl,lg) in zip(axes.flatten(),[("I_pv","I_pv (A)",0),("I_0","I_0 (A)",1),
                                               ("Rs","R_s (mΩ)",0),("N_a","N_a",0)]):
        for T,g in df.groupby("T"):
            g=g.sort_values("phi"); ax.plot(g["phi"],g[col],"-o",ms=3,label=f"T={T:.0f}°C")
        ax.set_xscale("symlog",linthresh=.5)
        if lg: ax.set_yscale("log")
        ax.set_xlabel("Φ (E14)"); ax.set_ylabel(yl); ax.grid(ls=":",alpha=.6)
    axes[0,0].legend(fontsize=8); fig.tight_layout()

def fig_iv_pv_TS(c,modele):
    fig,(ax_i,ax_p)=plt.subplots(1,2,figsize=(14,5.5),dpi=150)
    cmap=plt.get_cmap("turbo",3)
    for j,S in enumerate((1367.,1353.,1000.)):
        for phi,ls in [(0,"-"),(10,"--"),(100,":")]:
            st=predire_completes(c,modele,phi,c.get("T_ref_K",T_REF_K),S)
            d=extraire_diode_v28(st["Voc"],st["Isc"],st["Vmp"],st["Imp"],c.get("T_ref_K",T_REF_K),c.get("N_s",3))
            if not d or d.get("statut")!="actif": continue
            vv,iv,pv=courbe_iv(d,st["Voc"],c.get("T_ref_K",T_REF_K),c.get("N_s",3))
            ax_i.plot(vv,iv,color=cmap(j),ls=ls,lw=1.5,label=f"S={S:.0f},Φ={phi:g}")
            ax_p.plot(vv,pv,color=cmap(j),ls=ls,lw=1.5)
    ax_i.set_xlabel("V (V)"); ax_i.set_ylabel("I (A)")
    ax_i.legend(fontsize=6.5,ncol=2); ax_i.grid(ls=":",alpha=.6)
    ax_p.set_xlabel("V (V)"); ax_p.set_ylabel("P (W)")
    ax_p.grid(ls=":",alpha=.6); fig.tight_layout()

def fig_pmax_vs_T(c,modele):
    TK=np.linspace(C2K(20),C2K(110),12); fig,ax=plt.subplots(figsize=(9,5.5),dpi=150)
    for phi,col in [(0,"tab:green"),(10,"tab:orange"),(100,"tab:red")]:
        pp=[predire_completes(c,modele,phi,T,S_REF)["Vmp"]*
            predire_completes(c,modele,phi,T,S_REF)["Imp"] for T in TK]
        ax.plot(K2C(TK),pp,"-",color=col,lw=2,label=f"Φ={phi:g}E14")
    ax.set_xlabel("T (°C)"); ax.set_ylabel("P_max (W)")
    ax.legend(); ax.grid(ls=":",alpha=.6); fig.tight_layout()

# =============================================================================
# 10. INTERFACE BILINGUE / BILINGUAL INTERFACE
# =============================================================================
COPYRIGHT = """
==========================================================================
© 2026 — JUMEAU NUMÉRIQUE PV v28 | [Votre Nom] — CDS Engineering
Licence MIT (code) | CC-BY-NC 4.0 (données dérivées / derived data).
Datasheets © fabricants / manufacturers. Outils IA: rédaction/formatage only.
=========================================================================="""

BANNIERE = f"""
==========================================================================
☀️  JUMEAU NUMÉRIQUE CELLULES SOLAIRES SPATIALES — v28
    DIGITAL TWIN OF SPACE SOLAR CELLS
    Source : {SOURCE}
    {N_CELLS} {tx('cellules','cells')} | kelvin | ECSS / MIL-STD / NASA
    [v28] F3 + F5 + 8 canaux + recuit + impacts + RDC + 3J + optique + cryo
=========================================================================="""

MODULES = [
    ("1",  "Charger & valider + provenance", "Load & validate + provenance", run_data),
    ("2",  "Dégradation (C*,Φ₀) + Mémoire", "Degradation (C*,Phi0) + Memory", run_deg),
    ("3",  "Bootstrap UQ",                   "Bootstrap UQ",                   run_boot),
    ("4",  "Diode Lambert W multi-T",        "Lambert W diode multi-T",        run_diode),
    ("5",  "Auto-tests T1–T5",               "Self-tests T1–T5",               run_tests),
    ("6",  "Figures",                        "Figures",                        run_fig),
    ("7",  "Benchmark 59 BOL",               "Benchmark 59 BOL",               run_bench),
    ("8",  "Export Excel",                   "Export Excel",                   run_export),
    ("13", "Plages & normes",                "Ranges & standards",             run_temp),
    ("14", "Extraction (T,Φ)",               "Extraction (T,Phi)",             run_custom),
    ("15", "Calibration R_s fixé",           "Fixed-Rs calibration",           run_caler),
    ("16", "Variables fixées",               "Fixed variables",                run_fix),
    # [v28] Modules avancés / Advanced modules
    ("17", "Dommage total (8 canaux)",       "Total damage (8 channels)",      run_dommage_total),
    ("18", "Recuit & récupération",          "Annealing & recovery",           run_recuit),
    ("19", "Vieillissement thermique",       "Thermal aging",                  run_vieillissement),
    ("20", "Impacts & ESD",                  "Impacts & ESD",                  run_impacts),
    ("21", "RDC / fluence équivalente",      "RDC / equivalent fluence",       run_rdc),
    ("23", "Sous-cellules 3J",               "3J subcells",                    run_tj),
    ("24", "Optique",                        "Optics",                         run_optique),
    ("25", "Profil mission (cryo/LLL)",      "Mission profile (cryo/LLL)",     run_mission_profile),
]

FULL_ORDER = ["1","2","3","4","5","6","7","8"]

def afficher_banniere():
    """[FR] Affiche la bannière. [EN] Prints the banner."""
    print(BANNIERE)

def afficher_menu():
    print("\n"+"="*74); print(BANNIERE); print("="*74)
    print("  [0] TOUT → "+tx("pipeline complet","full pipeline"))
    for k,lf,le,_ in MODULES: print(f"  [{k:>2}] {tx(lf,le)}")
    print("-"*74)
    print("  [9] "+tx("Cellules","Cells")+" | [10] Config | "
          "[11] "+tx("Références","References")+" | [12] Copyright | "
          "[q] "+tx("Quitter","Quit"))
    print("-"*74)

def parser_choix(s): return [x for x in s.replace(";"," ").replace(","," ").split()]

def executer_cles(cles):
    dico={k:fn for k,_lf,_le,fn in MODULES}
    for k in cles:
        if k in dico: print(f">>> Module [{k}]"); dico[k]()

def configurer():
    print(f"\n  cœurs={ETAT['cores']}  boot={ETAT['nboot']}  "
          f"plot={ETAT['plot']}  lang={LANG}  mission={ETAT['mission_profile']}")
    c=input("  cœurs [enter]: ").strip()
    if c.isdigit(): ETAT["cores"]=int(c)
    b=input("  bootstrap [enter]: ").strip()
    if b.isdigit(): ETAT["nboot"]=int(b)
    l=input("  lang (fr/en/both) [enter]: ").strip().lower()
    if l: set_lang(l)
    p=input("  figures (o/n) [enter]: ").strip().lower()
    if p in ("o","n"): ETAT["plot"]=(p=="o")

def choisir_cellules():
    print("\n  "+tx("Cellules:","Cells:"))
    for i,c in enumerate(CELLULES_PHYSIQUE): print(f"  {i:2d}. {c.get('ref','?')}")
    s=input("  "+tx("indices ou 'all': ","indices or 'all': ")).strip()
    if s.lower()=="all" or s=="": ETAT["selection"]=list(CELLULES_PHYSIQUE)
    else:
        idx=[int(x) for x in s.split() if x.isdigit()]
        ETAT["selection"]=[CELLULES_PHYSIQUE[i] for i in idx if i<len(CELLULES_PHYSIQUE)]
    print(f"  → {len(ETAT['selection'])} "+tx("cellule(s)","cell(s)"))

def boucle_interactive():
    afficher_banniere()
    while True:
        afficher_menu(); ch=input("  "+tx("choix: ","choice: ")).strip().lower()
        if ch=="q": print("👋 "+tx("Au revoir.","Goodbye.")); break
        if ch=="0": executer_cles(FULL_ORDER); continue
        if ch=="9": choisir_cellules(); continue
        if ch=="10": configurer(); continue
        if ch=="11": print("\n"+REFERENCES_BIBLIOGRAPHIQUES); continue
        if ch=="12": print(COPYRIGHT); continue
        cles=parser_choix(ch)
        if cles: executer_cles(cles)
        else: print("  "+tx("Choix invalide.","Invalid choice."))

# =============================================================================
# 11. POINT D'ENTRÉE / ENTRY POINT
# =============================================================================
def main():
    p=argparse.ArgumentParser(description="Jumeau numérique PV v28 / Digital twin")
    p.add_argument("--mode",choices=["menu","full","modules"],default=None)
    p.add_argument("--modules",default="")
    p.add_argument("--cores",type=int,default=N_CORES)
    p.add_argument("--bootstrap",type=int,default=N_BOOTSTRAP)
    p.add_argument("--lang",choices=["fr","en","both"],default="both")
    p.add_argument("--no-plot",action="store_true")
    p.add_argument("--mission",default="LEO_STANDARD",
                   help="Profil mission: LEO_STANDARD, GEO_STANDARD, JUICE_JUPITER, MARS_SURFACE")
    a=p.parse_args()
    set_lang(a.lang)
    ETAT["cores"]=a.cores; ETAT["nboot"]=a.bootstrap; ETAT["plot"]=not a.no_plot
    if a.mission in PROFILS_MISSION: ETAT["mission_profile"]=a.mission
    normaliser_si(CELLULES_PHYSIQUE)
    mode=a.mode or ("menu" if sys.stdin.isatty() else "full")
    if mode=="full": executer_cles(FULL_ORDER)
    elif mode=="modules" and a.modules: executer_cles(parser_choix(a.modules))
    else: boucle_interactive()

if __name__=="__main__": main()

# =============================================================================
# 12. NOTES PHYSIQUES & RÉFÉRENCES / PHYSICS NOTES & REFERENCES
# =============================================================================
"""
NOTES PHYSIQUES / PHYSICS NOTES

1.  Loi de Tada [31] : X(Φ)=X₀[1−C·ln(1+Φ/Φ₀)] ; intersections analytiques.
2.  Projection conservative C* → « never above » (sécurité orbitale).
3.  1-diode + Lambert W [32,33]. 2-diodes pour LLL < 200 W/m² [v28].
4.  Corrections ECSS [34] : Isc∝S ; Voc+=N_s·V_t·ln(S/S_ref) ; dX/dT linéaire.
5.  Calibration R_s fixé [15] : forme fermée I₀,I_pv ; racine 1-D sur n (Brent).
6.  Variables fixées [16] : ancrage externe via pv_memoire/fix_variables.json.
7.  Plages : qualif −175→+140°C ; robustesse ±10 K ; Lune −240→+121°C.
8.  Bootstrap [7] : ancrage BOL ; IC 95 % = percentiles 2.5/97.5.
9.  [v28-F3] Fluence structurée : particule, énergie, unité, fluence_type, RDC.
10. [v28-F5] SEUIL_REJET = 5% : si erreur > 5%, statut = REJETÉ.
11. [v28-F5] R_sh optionnel (si I-V complète disponible).
12. [v28-M22] Composition multiplicative : D_total = 1 − ∏(1−D_i·w_i).
    JAMAIS additionner les D_i. Toujours composer les fractions restantes.
13. [v28-M18] Recuit : k(T) = A·exp(−Ea/k_BT). Canal rad UNIQUEMENT.
    9 mécanismes : REC_007 à REC_014 + REC_047.
14. [v28-M19] Vieillissement thermique : dose Arrhenius cumulée. PERMANENT.
15. [v28-M20] Impacts : Paul-Berthoud [107]. ESD : Q=I²Rt. PERMANENT.
16. [v28-M21] RDC : Φ_eq = Φ × RDC. Source : Rapport RT3 CDS.
    RDC 3MeV→1MeV = 2.66 ; RDC 9.5MeV→1MeV = 9.03.
17. [v28-M23] Current matching 3J : Isc_3J = min(I_top, I_mid, I_bot). Kirchhoff.
18. [v28-M24] Optique : D_opt = 1 − T_eol/T_bol. Beer-Lambert. PERMANENT.
19. [v28-CRYO] Mode cryogénique (JUICE) : recuit désactivé, 2-diodes LLL,
    facteur correction dommage ×1.25. T ≈ 100-150 K. S ≈ 50 W/m².
20. [v28-CRYO] Mode Mars : recuit désactivé, 2-diodes LLL, ×1.10.

CORRECTIONS v26 : [1] THERMO en SI ; [2] bench WARNING si eff>40 ; [3] feuille dynamique.
AJOUTS v27 : [S1] POIDS/provenance ; [S2] traçage repli THERMO ; [F2] provenance_elec ;
             [F4] component_type.
AJOUTS v28 : [F3] fluence structurée ; [F5] seuil de rejet + R_sh ;
             [M17-M25] 9 modules avancés ; [CRYO] profils mission Deep Space.

RÉFÉRENCES / REFERENCES (complètes via REFERENCES_BIBLIOGRAPHIQUES, menu [11])
[7]   Efron & Tibshirani (1993).        [28] Pindado 2017.
[29]  Pindado 2018.                     [30] Ramadan 2022.
[31]  Tada JPL 82-69 (1982).            [32] Jain & Kapoor 2004.
[33]  Corless 1996.                     [34] ECSS-E-ST-20-08C Rev.2.
[35]  Messenger (NIEL/DDD).             [36] IEEE PVSC 2010.
[105] Rival & Mandeville 1999.          [107] Paul & Berthoud 1995.
[123] Baur & Bett 2010.                 [124] Imaizumi 2017.
[A]   Blanco ESPC 2016.                 [B] Paige LRO Diviner 2010.
"""