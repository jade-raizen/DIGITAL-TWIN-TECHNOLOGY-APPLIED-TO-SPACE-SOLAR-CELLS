#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
TESTS — validation/tests.py (v1.0, BILINGUE)
Test Suite: T1-T5 + tests for new modules M17-M24
===============================================================================
"""
from __future__ import annotations
import numpy as np
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "models"))

from config import *
from electrical_model import extraire_diode
from radiation_model import selection_conservatrice
from thermal_model import corriger_temperature
from annealing_model import run_recuit

__version__ = "1.0"

# =============================================================================
# T1-T5 : TESTS EXISTANTS / EXISTING TESTS
# =============================================================================
def test_T1_MPP_diode():
    """T1 : P_max diode ≈ Vmp×Imp (erreur < 2%)"""
    voc, isc, vmp, imp = 2.700, 0.5202, 2.411, 0.5044
    d = extraire_diode(voc, isc, vmp, imp, T_REF_K, ns=3)
    if d is None:
        return False, "Extraction échouée"
    err = abs(d['P_max'] - vmp * imp) / (vmp * imp)
    return err < 0.02, f"Erreur = {err:.2%}"

def test_T2_never_above():
    """T2 : Prédiction jamais au-dessus de la mesure"""
    voc = np.array([2.700, 2.620, 2.570, 2.510])
    flu = np.array([0.0, 2.5, 5.0, 10.0])
    result = selection_conservatrice(voc, flu)
    if result is None:
        return False, "Extraction échouée"
    C, Phi0, R2 = result
    pred = voc[0] * (1 - C * np.log(1 + flu / Phi0))
    violations = np.sum(pred > voc * (1 + TOL))
    return violations == 0, f"{violations} violation(s)"

def test_T3_P_S_increasing():
    """T3 : P(S) croissant avec S"""
    return True, "Test à implémenter avec données complètes"

def test_T4_P_T_decreasing():
    """T4 : P(T) décroissant avec T"""
    return True, "Test à implémenter avec données complètes"

def test_T5_Bootstrap():
    """T5 : Bootstrap convergé"""
    return True, "Test à implémenter avec données complètes"

# =============================================================================
# NOUVEAUX TESTS M17-M24 / NEW TESTS M17-M24
# =============================================================================
def test_M18_recuit():
    """M18 : Recuit thermique produit une récupération > 0"""
    cfg = {
        "actif": True, "type_recuit": "arrhenius", "t_h": 100.0,
        "T_profil": [[0, 300.0], [50, 350.0], [100, 300.0]],
        "familles": [{"nom": "E1", "A": 1e9, "Ea": 0.85, "D0": 1.0}],
    }
    res = run_recuit(cfg)
    if res["statut"] != "actif":
        return False, res.get("raison", "Erreur inconnue")
    return res["recuperation_pct"] > 0, f"Récupération = {res['recuperation_pct']:.1f}%"

def test_M22_composition_multiplicative():
    """M22 : Composition multiplicative donne D_total ∈ [0,1]"""
    dom = {"rad": 0.15, "opt": 0.05}
    for p in PARAMS_ELEC:
        D = dommage_total(dom, p)
        if not (0 <= D <= 1):
            return False, f"D_total({p}) = {D} hors [0,1]"
    return True, "Tous D_total ∈ [0,1]"

# =============================================================================
# MAIN / RUN ALL TESTS
# =============================================================================
if __name__ == "__main__":
    print(f"🧪 tests.py v{__version__}")
    tests = [
        ("T1 MPP diode", test_T1_MPP_diode),
        ("T2 Never above", test_T2_never_above),
        ("T3 P(S) increasing", test_T3_P_S_increasing),
        ("T4 P(T) decreasing", test_T4_P_T_decreasing),
        ("T5 Bootstrap", test_T5_Bootstrap),
        ("M18 Recuit", test_M18_recuit),
        ("M22 Composition", test_M22_composition_multiplicative),
    ]
    
    passed = 0
    for name, fn in tests:
        ok, msg = fn()
        status = "✅ PASS" if ok else "❌ FAIL"
        print(f"   {status} {name} : {msg}")
        if ok:
            passed += 1
    
    print(f"\n   Résultat : {passed}/{len(tests)} tests passés")