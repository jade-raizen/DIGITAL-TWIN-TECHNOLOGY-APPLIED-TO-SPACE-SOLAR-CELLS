#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
===============================================================================
MODÈLE MÉCANIQUE — models/mechanical_model.py (v1.0, BILINGUE)
Mechanical Model: Fatigue, cracking, delamination, CTE mismatch
===============================================================================
"""
from __future__ import annotations
import numpy as np
from config import POIDS, resultat_non_identifiable

__version__ = "1.0"

# =============================================================================
# 1. FATIGUE THERMIQUE (COFFIN-MANSON) / THERMAL FATIGUE
# =============================================================================
def fatigue_coffin_manson(delta_eps, C=None, n=None):
    """[FR] Nombre de cycles à rupture Nf = C·(Δε)^(-n). PERMANENT.
    [EN] Cycles to failure. PERMANENT."""
    if C is None or n is None:
        return resultat_non_identifiable("fatigue", "C et n manquants (Coffin-Manson)")
    if delta_eps <= 0:
        return {"statut": "actif", "Nf": np.inf, "poids_confiance": POIDS["numerique"]}
    Nf = C * (delta_eps ** (-n))
    return {
        "statut": "actif",
        "Nf": float(Nf),
        "reversible": False,
        "poids_confiance": POIDS["numerique"],
    }

# =============================================================================
# 2. CONTRAINTE THERMIQUE (CTE MISMATCH) / THERMAL STRESS
# =============================================================================
def contrainte_thermique(E, delta_alpha, delta_T, nu=0.3):
    """[FR] Contrainte thermoélastique σ = E·Δα·ΔT/(1-ν).
    [EN] Thermoelastic stress."""
    sigma = E * delta_alpha * delta_T / (1 - nu)
    return {
        "statut": "actif",
        "sigma_Pa": float(sigma),
        "poids_confiance": POIDS["analytique"],
    }

# =============================================================================
# 3. AUTO-TEST / SELF-TEST
# =============================================================================
if __name__ == "__main__":
    print(f"⚙️  mechanical_model.py v{__version__}")
    res = contrainte_thermique(70e9, 3e-6, 100.0, 0.3)
    print(f"   σ = {res['sigma_Pa']/1e6:.1f} MPa")